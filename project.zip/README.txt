RedmiCam - HDR (normal + -4EV, background-only highlight recovery)

Build: open this folder in Android Studio (Gradle sync) -> Run.
First HDR photo: allow notifications and battery "No restrictions".
Xiaomi/HyperOS: Settings > Apps > Redmi Cam > Autostart ON, Battery saver = No restrictions
(otherwise the phone can still kill background processing).

Code map
  MainActivity.kt   UI (HDR / aspect ratio / shutter / gallery), 2-frame capture
  HdrService.kt     foreground service, job queue on disk, notification progress
  FrameIo.kt        JPEG decode/rotate/crop + engine <-> Bitmap glue
  hdr/              pure-Kotlin HDR engine (aligned, exposure matched, background-only merge)
