package com.rohan.redmicam.hdr

import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/** Dense motion field: pixel (x, y) of the normal frame is found at (x + fx, y + fy) of the dark frame. */
internal class FlowField(val w: Int, val h: Int, val fx: FloatArray, val fy: FloatArray)

/**
 * Exposure-independent alignment of the dark (-4 EV) frame onto the normal frame.
 *
 * Gradients of the *logarithm* of luminance do not change when a frame is simply darker, so both
 * frames can be compared directly. Pixels that are clipped in the normal frame or buried in noise
 * in the dark frame get zero weight. Steps: coarse global search on a pyramid, then a per-tile
 * refinement with sub-pixel accuracy, outlier rejection and smoothing (handles small rotation,
 * rolling shutter and perspective change between the two shots).
 */
internal object HdrAlign {

    private class Img(val w: Int, val h: Int, val lg: FloatArray, val v: FloatArray)

    private class Grad(
        val w: Int, val h: Int,
        val gx: FloatArray, val gy: FloatArray, val wt: FloatArray
    )

    private fun makeImg(y: FloatArray, w: Int, h: Int, lo: Float, hi: Float): Img {
        val v = FloatArray(y.size) { if (y[it] in lo..hi) 1f else 0f }
        val lg = FloatArray(y.size) { ln(max(y[it], 1e-4f)) }
        // light denoise on valid pixels only
        val (m, den) = HdrMath.normBox(lg, v, w, h, 1)
        val out = FloatArray(y.size) { if (v[it] > 0f && den[it] > 0f) m[it] else lg[it] }
        return Img(w, h, out, v)
    }

    private fun down(a: Img): Img {
        val w2 = a.w / 2
        val h2 = a.h / 2
        val lg = FloatArray(w2 * h2)
        val v = FloatArray(w2 * h2)
        for (y in 0 until h2) for (x in 0 until w2) {
            var s = 0f
            var sl = 0f
            for (dy in 0..1) for (dx in 0..1) {
                val i = (2 * y + dy) * a.w + 2 * x + dx
                s += a.v[i]
                sl += a.lg[i] * a.v[i]
            }
            val o = y * w2 + x
            v[o] = s * 0.25f
            lg[o] = if (s > 0f) sl / s else 0f
        }
        return Img(w2, h2, lg, v)
    }

    private fun grad(a: Img): Grad {
        val w = a.w
        val h = a.h
        val gx = FloatArray(w * h)
        val gy = FloatArray(w * h)
        val wt = FloatArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            gx[i] = (a.lg[i + 1] - a.lg[i - 1]) * 0.5f
            gy[i] = (a.lg[i + w] - a.lg[i - w]) * 0.5f
            wt[i] = min(min(a.v[i], a.v[i - 1]), min(min(a.v[i + 1], a.v[i - w]), a.v[i + w]))
        }
        return Grad(w, h, gx, gy, wt)
    }

    private var lastWs = 0f

    /** Robust gradient-difference cost of region [x0,x1)x[y0,y1) of N against U shifted by (dx,dy). */
    private fun cost(
        n: Grad, u: Grad, dx: Int, dy: Int,
        x0: Int, y0: Int, x1: Int, y1: Int, step: Int
    ): Float {
        var s = 0f
        var ws = 0f
        val w = n.w
        val h = n.h
        var y = max(y0, 1)
        while (y < min(y1, h - 1)) {
            val yy = y + dy
            if (yy >= 1 && yy < h - 1) {
                var x = max(x0, 1)
                while (x < min(x1, w - 1)) {
                    val xx = x + dx
                    if (xx >= 1 && xx < w - 1) {
                        val i = y * w + x
                        val j = yy * w + xx
                        val wt = n.wt[i] * u.wt[j]
                        if (wt > 0f) {
                            val e = min(abs(n.gx[i] - u.gx[j]), 0.6f) + min(abs(n.gy[i] - u.gy[j]), 0.6f)
                            s += wt * e
                            ws += wt
                        }
                    }
                    x += step
                }
            }
            y += step
        }
        lastWs = ws
        return if (ws <= 0f) Float.MAX_VALUE else s / ws
    }

    private class Pt(val x: Int, val y: Int)

    private fun search(n: Grad, u: Grad, cx: Int, cy: Int, r: Int): Pt {
        val step = if (n.w * n.h > 60000) 2 else 1
        val c0 = cost(n, u, cx, cy, 0, 0, n.w, n.h, step)
        val wsRef = lastWs
        var best = c0
        var bx = cx
        var by = cy
        for (dy in -r..r) for (dx in -r..r) {
            val c = cost(n, u, cx + dx, cy + dy, 0, 0, n.w, n.h, step)
            if (lastWs < max(20f, 0.4f * wsRef)) continue
            if (c < best) {
                best = c; bx = cx + dx; by = cy + dy
            }
        }
        // only trust a shift that is clearly better than "no change"
        return if (best < c0 * 0.97f) Pt(bx, by) else Pt(cx, cy)
    }

    /**
     * Per-tile motion at one pyramid level. [bfx]/[bfy] hold the motion known from the coarser
     * level (or the global shift); every tile searches +-[radius] pixels around it with
     * sub-pixel refinement. Returns a dense field for this level.
     */
    private fun tileLevel(
        n: Grad, u: Grad, bfx: FloatArray, bfy: FloatArray, radius: Int
    ): Pair<FloatArray, FloatArray> {
        val w = n.w
        val h = n.h
        val tile = min(32, max(16, min(w, h) / 6))
        val stride = tile / 2
        val gw = max(1, (w - tile) / stride + 1)
        val gh = max(1, (h - tile) / stride + 1)
        val tfx = FloatArray(gw * gh) { Float.NaN }
        val tfy = FloatArray(gw * gh) { Float.NaN }
        val side = 2 * radius + 1
        val costs = FloatArray(side * side)

        for (ty in 0 until gh) for (tx in 0 until gw) {
            val x0 = tx * stride
            val y0 = ty * stride
            val cxp = min(w - 1, x0 + tile / 2)
            val cyp = min(h - 1, y0 + tile / 2)
            val bx = Math.round(bfx[cyp * w + cxp])
            val by = Math.round(bfy[cyp * w + cxp])
            val c0 = cost(n, u, bx, by, x0, y0, x0 + tile, y0 + tile, 1)
            val ws0 = lastWs
            if (ws0 < 0.12f * tile * tile) continue
            var best = c0
            var bdx = 0
            var bdy = 0
            for (dy in -radius..radius) for (dx in -radius..radius) {
                val c = cost(n, u, bx + dx, by + dy, x0, y0, x0 + tile, y0 + tile, 1)
                val ok = lastWs >= 0.6f * ws0
                costs[(dy + radius) * side + dx + radius] = if (ok) c else Float.MAX_VALUE
                if (ok && c < best) {
                    best = c; bdx = dx; bdy = dy
                }
            }
            var ox = 0f
            var oy = 0f
            if (best < c0 * 0.93f) {
                ox = bdx.toFloat()
                oy = bdy.toFloat()
                if (abs(bdx) < radius && abs(bdy) < radius) {
                    fun cc(ix: Int, iy: Int) = costs[(iy + radius) * side + ix + radius]
                    val l = cc(bdx - 1, bdy); val m = cc(bdx, bdy); val r = cc(bdx + 1, bdy)
                    val up = cc(bdx, bdy - 1); val dn = cc(bdx, bdy + 1)
                    if (l < Float.MAX_VALUE && r < Float.MAX_VALUE && l + r - 2 * m > 1e-6f) {
                        ox += (0.5f * (l - r) / (l + r - 2 * m)).coerceIn(-0.5f, 0.5f)
                    }
                    if (up < Float.MAX_VALUE && dn < Float.MAX_VALUE && up + dn - 2 * m > 1e-6f) {
                        oy += (0.5f * (up - dn) / (up + dn - 2 * m)).coerceIn(-0.5f, 0.5f)
                    }
                }
            }
            tfx[ty * gw + tx] = bx + ox
            tfy[ty * gw + tx] = by + oy
        }

        // tiles with too little texture take the average of their neighbours
        for (iter in 0 until gw + gh) {
            var any = false
            val nx = tfx.copyOf()
            val ny = tfy.copyOf()
            for (ty in 0 until gh) for (tx in 0 until gw) {
                val i = ty * gw + tx
                if (!tfx[i].isNaN()) continue
                var sx = 0f; var sy = 0f; var c = 0
                for (dy in -1..1) for (dx in -1..1) {
                    val xx = tx + dx; val yy = ty + dy
                    if (xx < 0 || yy < 0 || xx >= gw || yy >= gh) continue
                    val j = yy * gw + xx
                    if (!tfx[j].isNaN()) { sx += tfx[j]; sy += tfy[j]; c++ }
                }
                if (c > 0) { nx[i] = sx / c; ny[i] = sy / c } else any = true
            }
            System.arraycopy(nx, 0, tfx, 0, tfx.size)
            System.arraycopy(ny, 0, tfy, 0, tfy.size)
            if (!any) break
        }
        for (i in tfx.indices) {
            if (tfx[i].isNaN()) {
                val cx = min(w - 1, (i % gw) * stride + tile / 2)
                val cy = min(h - 1, (i / gw) * stride + tile / 2)
                tfx[i] = bfx[cy * w + cx]
                tfy[i] = bfy[cy * w + cx]
            }
        }

        // outliers (a tile that locked onto a moving object) and smoothing
        var sfx = HdrMath.median3(tfx, gw, gh)
        var sfy = HdrMath.median3(tfy, gw, gh)
        sfx = HdrMath.box(sfx, gw, gh, 1)
        sfy = HdrMath.box(sfy, gw, gh, 1)

        val fx = FloatArray(w * h)
        val fy = FloatArray(w * h)
        val half = tile / 2f
        for (y in 0 until h) {
            val gyc = (y - half) / stride
            for (x in 0 until w) {
                val gxc = (x - half) / stride
                fx[y * w + x] = HdrMath.sample(sfx, gw, gh, gxc, gyc)
                fy[y * w + x] = HdrMath.sample(sfy, gw, gh, gxc, gyc)
            }
        }
        return Pair(fx, fy)
    }

    fun estimate(yN: FloatArray, yU: FloatArray, w: Int, h: Int): FlowField {
        val pyrN = ArrayList<Img>()
        val pyrU = ArrayList<Img>()
        pyrN.add(makeImg(yN, w, h, 0.03f, 0.85f))
        pyrU.add(makeImg(yU, w, h, 0.01f, 0.85f))
        while (pyrN.size < 4 && min(pyrN.last().w, pyrN.last().h) >= 96) {
            pyrN.add(down(pyrN.last()))
            pyrU.add(down(pyrU.last()))
        }
        val gN = pyrN.map { grad(it) }
        val gU = pyrU.map { grad(it) }
        val top = gN.size - 1

        // ---- global translation, coarse to fine
        var g = search(gN[top], gU[top], 0, 0, 10)
        for (l in top - 1 downTo 0) g = search(gN[l], gU[l], g.x * 2, g.y * 2, 2)

        // ---- local motion, coarse to fine (handles rotation / perspective / rolling shutter)
        // start at the coarsest level with a constant field
        val gtop = Pt(if (top == 0) g.x else Math.round(g.x / Math.pow(2.0, top.toDouble()).toFloat()),
            if (top == 0) g.y else Math.round(g.y / Math.pow(2.0, top.toDouble()).toFloat()))
        var fx = FloatArray(gN[top].w * gN[top].h) { gtop.x.toFloat() }
        var fy = FloatArray(gN[top].w * gN[top].h) { gtop.y.toFloat() }
        for (l in top downTo 0) {
            if (min(gN[l].w, gN[l].h) >= 64) {
                val r = tileLevel(gN[l], gU[l], fx, fy, if (l == top) 3 else 2)
                fx = r.first
                fy = r.second
            }
            if (l > 0) {
                val nw = gN[l - 1].w
                val nh = gN[l - 1].h
                val ow = gN[l].w
                val oh = gN[l].h
                val nfx = FloatArray(nw * nh)
                val nfy = FloatArray(nw * nh)
                for (y in 0 until nh) for (x in 0 until nw) {
                    val sx = (x + 0.5f) / 2f - 0.5f
                    val sy = (y + 0.5f) / 2f - 0.5f
                    nfx[y * nw + x] = 2f * HdrMath.sample(fx, ow, oh, sx, sy)
                    nfy[y * nw + x] = 2f * HdrMath.sample(fy, ow, oh, sx, sy)
                }
                fx = nfx
                fy = nfy
            }
        }
        return FlowField(w, h, fx, fy)
    }
}
