package com.rohan.redmicam

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

class HdrMergeWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val normalFile = inputData.getString(KEY_NORMAL)?.let(::File)
        val darkFile = inputData.getString(KEY_DARK)?.let(::File)
        if (normalFile == null || !normalFile.exists()) return Result.failure()

        var normal: Bitmap? = null
        var dark: Bitmap? = null
        var output: Bitmap? = null
        try {
            setForeground(createForegroundInfo())
            normal = BitmapFactory.decodeFile(normalFile.absolutePath) ?: return Result.failure()
            dark = darkFile?.takeIf { it.exists() }?.let {
                BitmapFactory.decodeFile(it.absolutePath)
            }
            output = HdrProcessor.merge(normal, dark)
            saveToGallery(output)
            return Result.success()
        } catch (t: Throwable) {
            return Result.failure()
        } finally {
            output?.recycle()
            normal?.recycle()
            dark?.recycle()
            normalFile.delete()
            darkFile?.delete()
        }
    }

    private fun createForegroundInfo(): ForegroundInfo {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "HDR photo processing", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification: Notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Processing HDR photo")
            .setContentText("Combining exposure frames and saving to Gallery")
            .setOngoing(true)
            .setProgress(0, 0, true)
            .build()
        return if (Build.VERSION.SDK_INT >= 34) {
            ForegroundInfo(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(NOTIFICATION_ID, notification)
        }
    }

    private fun saveToGallery(bitmap: Bitmap) {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_HDR_$stamp.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/RedmiNote14Cam")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val uri = applicationContext.contentResolver.insert(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ) ?: throw IllegalStateException("Gallery insert failed")
        try {
            applicationContext.contentResolver.openOutputStream(uri)?.use {
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 97, it)) {
                    throw IllegalStateException("JPEG encoding failed")
                }
            } ?: throw IllegalStateException("Gallery stream unavailable")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                applicationContext.contentResolver.update(
                    uri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null
                )
            }
        } catch (t: Throwable) {
            applicationContext.contentResolver.delete(uri, null, null)
            throw t
        }
    }

    companion object {
        const val KEY_NORMAL = "normal_path"
        const val KEY_DARK = "dark_path"
        const val CHANNEL_ID = "hdr_processing"
        const val NOTIFICATION_ID = 4107
    }
}
