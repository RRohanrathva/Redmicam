package com.rohan.redmicam.hdr

/**
 * The HDR engine is plain Kotlin (no android.* imports) so it can be unit-tested on a normal JVM.
 * Android code feeds it through these two tiny interfaces.
 */
interface RowSource {
    val width: Int
    val height: Int

    /** Reads [rows] rows starting at row [y] as ARGB ints into [out] (row stride = width). */
    fun readRows(y: Int, rows: Int, out: IntArray)
}

interface RowSink {
    /** Receives [rows] finished rows starting at row [y] (ARGB ints, row stride = width). */
    fun writeRows(y: Int, rows: Int, px: IntArray)
}

class HdrOptions(
    /** Subject position (where the user tapped / focus point), 0..1 of the final, upright image. */
    val focusX: Float = 0.5f,
    val focusY: Float = 0.5f,
    /** How many stops darker the second frame was meant to be (used only as a sanity prior). */
    val nominalStops: Float = 4f
)

class HdrReport {
    /** Exposure difference between the two frames that was measured from the pixels, in stops. */
    var stops = 0f
    var blownPercent = 0f
    var recoveredPercent = 0f
    var merged = false
    var note = ""
    override fun toString() =
        "HdrReport(stops=%.2f blown=%.2f%% recovered=%.2f%% merged=%s note=%s)".format(
            stops, blownPercent, recoveredPercent, merged, note
        )
}

class HdrCancelled : RuntimeException("HDR cancelled")
