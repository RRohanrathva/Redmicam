package com.rohan.redmicam

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.hardware.camera2.CaptureRequest
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.common.util.concurrent.ListenableFuture
import com.rohan.redmicam.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Properties
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var imageCapture: ImageCapture? = null
    private var camera: Camera? = null

    private var hdrEnabled = true
    private var capturing = false

    private class RawFrame(val jpeg: ByteArray, val rotation: Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val perms = REQUIRED_PERMISSIONS.toMutableList()
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        if (allPermissionsGranted()) {
            startCamera()
        } else {
            ActivityCompat.requestPermissions(this, perms.toTypedArray(), REQUEST_CODE_PERMISSIONS)
        }

        binding.btnHdr.setOnClickListener {
            hdrEnabled = !hdrEnabled
            updateHdrButton()
            startCamera()
        }

        binding.btnCapture.setOnClickListener {
            if (capturing) return@setOnClickListener
            if (hdrEnabled) captureHdr() else takeStandardPhoto()
        }

        setupTapToFocus()
        updateHdrButton()

        HdrQueueState.listener = { n -> showQueue(n) }
        showQueue(HdrQueueState.pending)

        // resume jobs that were left over (app closed while processing)
        val leftovers = File(filesDir, "hdr_jobs").listFiles { f ->
            f.isDirectory && File(f, "meta.txt").exists()
        }
        if (!leftovers.isNullOrEmpty()) startHdrService()
    }

    override fun onDestroy() {
        HdrQueueState.listener = null
        super.onDestroy()
    }

    private fun showQueue(n: Int) {
        binding.tvHint.text =
            if (n > 0) "$n HDR photo background ma process thai rahya chhe\n(tame bija photos click kari shako)" else ""
    }

    private fun updateHdrButton() {
        binding.btnHdr.text = if (hdrEnabled) "HDR: ON" else "HDR: OFF"
        binding.btnHdr.setTextColor(if (hdrEnabled) Color.parseColor("#FFD600") else Color.WHITE)
    }

    private fun startHdrService() {
        ContextCompat.startForegroundService(this, Intent(this, HdrService::class.java))
    }

    // ---------------------------------------------------------------- tap to focus

    @SuppressLint("ClickableViewAccessibility")
    private fun setupTapToFocus() {
        binding.viewFinder.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                val cam = camera ?: return@setOnTouchListener false
                val factory = binding.viewFinder.meteringPointFactory
                val point = factory.createPoint(event.x, event.y)
                val action = FocusMeteringAction.Builder(
                    point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
                ).setAutoCancelDuration(3, TimeUnit.SECONDS).build()

                showFocusRing(event.x, event.y)
                try {
                    cam.cameraControl.startFocusAndMetering(action)
                } catch (e: Exception) {
                    // ignore
                }
                true
            } else {
                false
            }
        }
    }

    private fun showFocusRing(x: Float, y: Float) {
        val ring = binding.viewFocusRing
        ring.x = x - ring.width / 2f
        ring.y = y - ring.height / 2f
        ring.visibility = View.VISIBLE
        ring.scaleX = 1.5f
        ring.scaleY = 1.5f
        ring.alpha = 1.0f
        ring.animate()
            .scaleX(1.0f)
            .scaleY(1.0f)
            .setDuration(200)
            .withEndAction {
                ring.animate()
                    .alpha(0.0f)
                    .setStartDelay(800)
                    .setDuration(300)
                    .withEndAction { ring.visibility = View.INVISIBLE }
                    .start()
            }
            .start()
    }

    // ---------------------------------------------------------------- camera

    private fun photoResolutionSelector(): ResolutionSelector =
        ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(
                ResolutionStrategy(
                    Size(3264, 2448),
                    ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                )
            )
            .build()

    @OptIn(ExperimentalCamera2Interop::class)
    private fun startCamera() {
        if (!allPermissionsGranted()) return
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()

            val previewBuilder = Preview.Builder()
            Camera2Interop.Extender(previewBuilder).setCaptureRequestOption(
                CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON
            )
            val preview = previewBuilder.build().also {
                it.setSurfaceProvider(binding.viewFinder.surfaceProvider)
            }

            val captureBuilder = ImageCapture.Builder()
                .setCaptureMode(
                    if (hdrEnabled) ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY
                    else ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY
                )
                .setResolutionSelector(photoResolutionSelector())
            Camera2Interop.Extender(captureBuilder).setCaptureRequestOption(
                CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON
            )
            val capture = captureBuilder.build()

            provider.unbindAll()
            try {
                camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
                imageCapture = capture

                val st = camera!!.cameraInfo.exposureState
                binding.tvInfo.visibility = View.VISIBLE
                binding.tvInfo.text = if (st.isExposureCompensationSupported) {
                    val step = st.exposureCompensationStep.toFloat()
                    val lo = st.exposureCompensationRange.lower * step
                    "Min exposure: ${"%.1f".format(Locale.US, lo)} EV"
                } else {
                    "Exposure bracketing supported nathi"
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Camera start error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // ---------------------------------------------------------------- HDR capture: 3 frames, then background merge

    @OptIn(ExperimentalCamera2Interop::class)
    private fun lockAwb(cam: Camera, lock: Boolean): ListenableFuture<*>? {
        return try {
            val c2 = Camera2CameraControl.from(cam.cameraControl)
            if (lock) {
                c2.setCaptureRequestOptions(
                    CaptureRequestOptions.Builder()
                        .setCaptureRequestOption(CaptureRequest.CONTROL_AWB_LOCK, true)
                        .build()
                )
            } else {
                c2.clearCaptureRequestOptions()
            }
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun ListenableFuture<*>.awaitIgnoringErrors() =
        suspendCancellableCoroutine<Unit> { cont ->
            addListener({
                if (cont.isActive) cont.resume(Unit)
            }, ContextCompat.getMainExecutor(this@MainActivity))
        }

    private fun setCapturing(on: Boolean) {
        capturing = on
        binding.btnCapture.alpha = if (on) 0.35f else 1f
    }

    private fun captureHdr() {
        val cap = imageCapture ?: return
        val cam = camera ?: return

        setCapturing(true)

        val st = cam.cameraInfo.exposureState
        val baseIndex = st.exposureCompensationIndex
        val step = st.exposureCompensationStep.toFloat()
        val range = st.exposureCompensationRange
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val jobDir = File(filesDir, "hdr_jobs/job_$stamp")

        lifecycleScope.launch {
            val frames = ArrayList<RawFrame>()
            val usedEv = ArrayList<Float>()
            try {
                withContext(Dispatchers.IO) { jobDir.mkdirs() }
                lockAwb(cam, true)?.awaitIgnoringErrors()

                // exposure plan: normal, then about -2 EV and -4 EV (limited by what the phone allows)
                val targets = ArrayList<Int>()
                targets.add(baseIndex)
                if (st.isExposureCompensationSupported && step > 0f) {
                    for (ev in floatArrayOf(-2f, -4f)) {
                        val idx = (baseIndex + (ev / step).roundToInt()).coerceIn(range.lower, range.upper)
                        if (idx < targets.last()) targets.add(idx)
                    }
                }

                for ((i, idx) in targets.withIndex()) {
                    if (idx != baseIndex || i > 0) {
                        cam.cameraControl.setExposureCompensationIndex(idx).awaitIgnoringErrors()
                        delay(700)
                    }
                    frames.add(captureRawFrame(cap))
                    usedEv.add((idx - baseIndex) * step)
                }
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Capture error: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                try {
                    cam.cameraControl.setExposureCompensationIndex(baseIndex)
                } catch (e: Exception) {
                    // ignore
                }
                lockAwb(cam, false)
                setCapturing(false)
            }

            if (frames.isEmpty()) return@launch

            val evText = usedEv.joinToString(" / ") { "%.1f".format(Locale.US, it) }
            Toast.makeText(
                this@MainActivity,
                "${frames.size} frames mali gaya ($evText EV). Background ma HDR process thase.",
                Toast.LENGTH_LONG
            ).show()

            // save frames + gallery placeholder + start background job (does not block the shutter)
            val app = applicationContext
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    for ((i, f) in frames.withIndex()) {
                        File(jobDir, "f$i.jpg").writeBytes(f.jpeg)
                    }
                    val name = "IMG_HDR_$stamp"
                    val placeholder = savePlaceholder(frames[0], name)

                    val props = Properties()
                    props.setProperty("frames", frames.size.toString())
                    props.setProperty("rotation", frames[0].rotation.toString())
                    props.setProperty("name", name)
                    props.setProperty("uri", placeholder?.toString() ?: "")
                    val tmp = File(jobDir, "meta.tmp")
                    tmp.outputStream().use { props.store(it, null) }
                    tmp.renameTo(File(jobDir, "meta.txt"))

                    withContext(Dispatchers.Main) {
                        ContextCompat.startForegroundService(app, Intent(app, HdrService::class.java))
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(app, "Save error: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private suspend fun captureRawFrame(capture: ImageCapture): RawFrame =
        suspendCancellableCoroutine { cont ->
            capture.takePicture(
                ContextCompat.getMainExecutor(this),
                object : ImageCapture.OnImageCapturedCallback() {
                    override fun onCaptureSuccess(image: ImageProxy) {
                        try {
                            val buffer = image.planes[0].buffer
                            val bytes = ByteArray(buffer.remaining())
                            buffer.get(bytes)
                            val rotation = image.imageInfo.rotationDegrees
                            image.close()
                            cont.resume(RawFrame(bytes, rotation))
                        } catch (e: Exception) {
                            image.close()
                            cont.resumeWithException(e)
                        }
                    }

                    override fun onError(exception: ImageCaptureException) {
                        cont.resumeWithException(exception)
                    }
                }
            )
        }

    /** The normal-exposure frame goes into the gallery at once; the service replaces it with the HDR result. */
    private fun savePlaceholder(frame: RawFrame, name: String): android.net.Uri? {
        val decoded = BitmapFactory.decodeByteArray(frame.jpeg, 0, frame.jpeg.size) ?: return null
        val upright: Bitmap = if (frame.rotation != 0) {
            val m = Matrix().apply { postRotate(frame.rotation.toFloat()) }
            val r = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, m, true)
            if (r !== decoded) decoded.recycle()
            r
        } else {
            decoded
        }
        try {
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.jpg")
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/RedmiNote14Cam")
                }
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return null
            contentResolver.openOutputStream(uri)?.use { upright.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            return uri
        } finally {
            upright.recycle()
        }
    }

    // ---------------------------------------------------------------- normal photo (HDR off)

    private fun takeStandardPhoto() {
        val capture = imageCapture ?: return
        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_$name")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/RedmiNote14Cam")
            }
        }
        val outputOptions = ImageCapture.OutputFileOptions.Builder(
            contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            contentValues
        ).build()

        capture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onError(exc: ImageCaptureException) {
                    Toast.makeText(baseContext, "Capture Failed: ${exc.message}", Toast.LENGTH_SHORT).show()
                }

                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    Toast.makeText(baseContext, "Photo Saved!", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    // ---------------------------------------------------------------- permissions

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                startCamera()
            } else {
                Toast.makeText(this, "Camera permission jaruri chhe", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    companion object {
        private const val REQUEST_CODE_PERMISSIONS = 10
        private val REQUIRED_PERMISSIONS = mutableListOf(
            Manifest.permission.CAMERA
        ).apply {
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }.toTypedArray()
    }
}
