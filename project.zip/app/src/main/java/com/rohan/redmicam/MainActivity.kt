package com.rohan.redmicam

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.*
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.rohan.redmicam.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null
    private var camera: Camera? = null

    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var currentMode = Mode.PHOTO
    private var flashMode = ImageCapture.FLASH_MODE_OFF
    private var currentAwbIndex = 0
    private var isProcessingHdr = false

    private val awbModes = listOf(
        Pair("AUTO", CaptureRequest.CONTROL_AWB_MODE_AUTO),
        Pair("DAYLIGHT", CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT),
        Pair("CLOUDY", CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT),
        Pair("TUNGSTEN", CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT)
    )

    enum class Mode { PHOTO, HDR, PORTRAIT, VIDEO }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (allPermissionsGranted()) {
            startCamera()
        } else {
            ActivityCompat.requestPermissions(
                this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS
            )
        }

        setupUIListeners()
        setupTapToFocus()
    }

    private fun setupUIListeners() {
        binding.btnModePhoto.setOnClickListener { switchMode(Mode.PHOTO) }
        binding.btnModeHdr.setOnClickListener { switchMode(Mode.HDR) }
        binding.btnModePortrait.setOnClickListener { switchMode(Mode.PORTRAIT) }
        binding.btnModeVideo.setOnClickListener { switchMode(Mode.VIDEO) }

        binding.btnCapture.setOnClickListener {
            if (isProcessingHdr) return@setOnClickListener
            when (currentMode) {
                Mode.VIDEO -> captureVideo()
                Mode.HDR -> captureSingleClickHdr()
                else -> takeStandardPhoto()
            }
        }

        binding.btnSwitchCamera.setOnClickListener {
            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
                CameraSelector.LENS_FACING_FRONT
            } else {
                CameraSelector.LENS_FACING_BACK
            }
            startCamera()
        }

        binding.btnFlash.setOnClickListener {
            flashMode = when (flashMode) {
                ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_ON
                ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_AUTO
                else -> ImageCapture.FLASH_MODE_OFF
            }
            binding.btnFlash.text = when (flashMode) {
                ImageCapture.FLASH_MODE_ON -> "Flash: ON"
                ImageCapture.FLASH_MODE_AUTO -> "Flash: AUTO"
                else -> "Flash: OFF"
            }
            imageCapture?.flashMode = flashMode
        }

        binding.btnAwb.setOnClickListener {
            currentAwbIndex = (currentAwbIndex + 1) % awbModes.size
            binding.btnAwb.text = "AWB: ${awbModes[currentAwbIndex].first}"
            startCamera()
        }

        binding.seekBarExposure.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val state = camera?.cameraInfo?.exposureState ?: return
                if (state.isExposureCompensationSupported) {
                    val range = state.exposureCompensationRange
                    val mappedEv = range.lower + ((range.upper - range.lower) * progress / 10)
                    camera?.cameraControl?.setExposureCompensationIndex(mappedEv)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    // Tap-to-Focus અને Exposure સેટ કરવા માટેનું ફંક્શન
    @SuppressLint("ClickableViewAccessibility")
    private fun setupTapToFocus() {
        binding.viewFinder.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                val cam = camera ?: return@setOnTouchListener false
                val factory = binding.viewFinder.meteringPointFactory
                
                // ટચ કરેલી જગ્યા (X, Y) ને કેમેરા પોઇન્ટમાં કન્વર્ટ કરો
                val point = factory.createPoint(event.x, event.y)
                val action = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
                    .setAutoCancelDuration(3, TimeUnit.SECONDS) // 3 સેકન્ડ પછી ઓટો ફોકસ રીસેટ થશે
                    .build()

                // UI પર ટચ કરેલી જગ્યાએ ફોકસ રિંગ બતાવો અને એનિમેટ કરો
                showFocusRing(event.x, event.y)

                // કેમેરા કંટ્રોલને ફોકસ અને એક્સપોઝર ટાસ્ક સોંપો
                try {
                    cam.cameraControl.startFocusAndMetering(action)
                } catch (e: Exception) {
                    // Ignore if cancelled
                }
                true
            } else {
                false
            }
        }
    }

    private fun showFocusRing(x: Float, y: Float) {
        val ring = binding.viewFocusRing
        // ટચ પોઇન્ટની બરાબર મધ્યમાં રિંગ સેટ કરો (Half width/height 36dp = 72px નો અડધો ભાગ)
        ring.x = x - ring.width / 2f
        ring.y = y - ring.height / 2f
        ring.visibility = View.VISIBLE
        ring.scaleX = 1.5f
        ring.scaleY = 1.5f
        ring.alpha = 1.0f

        ring.animate()
            .scaleX(1.0f)
            .scaleY(1.0f)
            .setDuration(200)
            .withEndAction {
                ring.animate()
                    .alpha(0.0f)
                    .setStartDelay(800)
                    .setDuration(300)
                    .withEndAction { ring.visibility = View.INVISIBLE }
                    .start()
            }
            .start()
    }

    private fun switchMode(newMode: Mode) {
        if (isProcessingHdr) return
        if (activeRecording != null) {
            activeRecording?.stop()
            activeRecording = null
        }
        currentMode = newMode
        updateModeColors()
        binding.btnCapture.text = if (currentMode == Mode.VIDEO) "REC" else "CLICK"
        startCamera()
    }

    private fun updateModeColors() {
        val activeColor = Color.parseColor("#FFD600")
        val normalColor = Color.WHITE
        binding.btnModePhoto.setTextColor(if (currentMode == Mode.PHOTO) activeColor else normalColor)
        binding.btnModeHdr.setTextColor(if (currentMode == Mode.HDR) activeColor else normalColor)
        binding.btnModePortrait.setTextColor(if (currentMode == Mode.PORTRAIT) activeColor else normalColor)
        binding.btnModeVideo.setTextColor(if (currentMode == Mode.VIDEO) activeColor else normalColor)
    }

    @OptIn(ExperimentalCamera2Interop::class)
    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val extensionsFuture = ExtensionsManager.getInstanceAsync(this, cameraProvider)

            extensionsFuture.addListener({
                val extensionsManager = extensionsFuture.get()
                val baseSelector = CameraSelector.Builder()
                    .requireLensFacing(lensFacing)
                    .build()

                val finalSelector = when (currentMode) {
                    Mode.HDR -> {
                        if (extensionsManager.isExtensionAvailable(baseSelector, ExtensionMode.HDR)) {
                            extensionsManager.getExtensionEnabledCameraSelector(baseSelector, ExtensionMode.HDR)
                        } else baseSelector
                    }
                    Mode.PORTRAIT -> {
                        if (extensionsManager.isExtensionAvailable(baseSelector, ExtensionMode.BOKEH)) {
                            extensionsManager.getExtensionEnabledCameraSelector(baseSelector, ExtensionMode.BOKEH)
                        } else baseSelector
                    }
                    else -> baseSelector
                }

                val previewBuilder = Preview.Builder()
                applyDimensitySensorTuning(previewBuilder)
                val preview = previewBuilder.build().also {
                    it.setSurfaceProvider(binding.viewFinder.surfaceProvider)
                }

                cameraProvider.unbindAll()

                if (currentMode == Mode.VIDEO) {
                    val recorder = Recorder.Builder()
                        .setQualitySelector(QualitySelector.from(Quality.FHD))
                        .build()
                    val newVideoCapture = VideoCapture.withOutput(recorder)
                    videoCapture = newVideoCapture
                    camera = cameraProvider.bindToLifecycle(this, finalSelector, preview, newVideoCapture)
                } else {
                    val captureBuilder = ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                        .setFlashMode(flashMode)
                    applyImageCaptureTuning(captureBuilder)
                    val newImageCapture = captureBuilder.build()
                    imageCapture = newImageCapture
                    camera = cameraProvider.bindToLifecycle(this, finalSelector, preview, newImageCapture)
                }

                verifyRedmiSensorCapabilities()
            }, ContextCompat.getMainExecutor(this))
        }, ContextCompat.getMainExecutor(this))
    }

    private fun captureSingleClickHdr() {
        val cap = imageCapture ?: return

        isProcessingHdr = true
        binding.btnCapture.isEnabled = false
        binding.btnCapture.text = "HDR..."

        lifecycleScope.launch {
            try {
                val singleShotBitmap = captureFrameBitmap(cap)

                binding.tvSensorStatus.text = "Applying Instant HDR+ Tone Mapping..."
                val hdrBitmap = HdrProcessor.processSingleClickHdr(singleShotBitmap)
                singleShotBitmap.recycle()

                saveBitmapToGallery(hdrBitmap, "IMG_HDR_1CLICK")
                hdrBitmap.recycle()

                Toast.makeText(this@MainActivity, "1-Click HDR+ Photo Saved!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "HDR Error: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                isProcessingHdr = false
                binding.btnCapture.isEnabled = true
                binding.btnCapture.text = "CLICK"
                verifyRedmiSensorCapabilities()
            }
        }
    }

    private suspend fun captureFrameBitmap(capture: ImageCapture): Bitmap =
        suspendCancellableCoroutine { cont ->
            capture.takePicture(
                ContextCompat.getMainExecutor(this),
                object : ImageCapture.OnImageCapturedCallback() {
                    override fun onCaptureSuccess(image: ImageProxy) {
                        try {
                            val bitmap = imageProxyToBitmap(image)
                            image.close()
                            cont.resume(bitmap)
                        } catch (e: Exception) {
                            image.close()
                            cont.resumeWithException(e)
                        }
                    }

                    override fun onError(exception: ImageCaptureException) {
                        cont.resumeWithException(exception)
                    }
                }
            )
        }

    private fun imageProxyToBitmap(image: ImageProxy): Bitmap {
        val buffer: ByteBuffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)

        val options = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val rawBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
        val rotation = image.imageInfo.rotationDegrees

        if (rotation == 0) return rawBitmap

        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
        val rotatedBitmap = Bitmap.createBitmap(
            rawBitmap, 0, 0, rawBitmap.width, rawBitmap.height, matrix, true
        )
        if (rotatedBitmap != rawBitmap) {
            rawBitmap.recycle()
        }
        return rotatedBitmap
    }

    private suspend fun saveBitmapToGallery(bitmap: Bitmap, prefix: String) = withContext(Dispatchers.IO) {
        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "${prefix}_$name.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/RedmiNote14Cam")
            }
        }

        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
        uri?.let {
            contentResolver.openOutputStream(it)?.use { stream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 96, stream)
            }
        }
    }

    @OptIn(ExperimentalCamera2Interop::class)
    private fun applyDimensitySensorTuning(builder: Preview.Builder) {
        val extender = Camera2Interop.Extender(builder)
        extender.setCaptureRequestOption(
            CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
            CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON
        )
        extender.setCaptureRequestOption(
            CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
            CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON
        )
        extender.setCaptureRequestOption(
            CaptureRequest.CONTROL_AWB_MODE,
            awbModes[currentAwbIndex].second
        )
    }

    @OptIn(ExperimentalCamera2Interop::class)
    private fun applyImageCaptureTuning(builder: ImageCapture.Builder) {
        val extender = Camera2Interop.Extender(builder)
        extender.setCaptureRequestOption(
            CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
            CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON
        )
        extender.setCaptureRequestOption(
            CaptureRequest.CONTROL_AWB_MODE,
            awbModes[currentAwbIndex].second
        )
        if (currentMode == Mode.HDR) {
            extender.setCaptureRequestOption(
                CaptureRequest.CONTROL_SCENE_MODE,
                CaptureRequest.CONTROL_SCENE_MODE_HDR
            )
        }
    }

    @OptIn(ExperimentalCamera2Interop::class)
    private fun verifyRedmiSensorCapabilities() {
        val info = camera?.cameraInfo ?: return
        val camera2Info = Camera2CameraInfo.from(info)
        val oisModes = camera2Info.getCameraCharacteristic(
            CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION
        )
        val hasOis = oisModes?.contains(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
        val oisText = if (hasOis) "OIS: ON" else "EIS: ON"
        val modeLabel = if (currentMode == Mode.HDR) "1-Click HDR+" else currentMode.name
        binding.tvSensorStatus.text = "Dimensity 7025U | LYT-600 | $oisText | $modeLabel"
    }

    private fun takeStandardPhoto() {
        val capture = imageCapture ?: return
        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_${currentMode}_$name")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/RedmiNote14Cam")
            }
        }

        val outputOptions = ImageCapture.OutputFileOptions.Builder(
            contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            contentValues
        ).build()

        capture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onError(exc: ImageCaptureException) {
                    Toast.makeText(baseContext, "Capture Failed: ${exc.message}", Toast.LENGTH_SHORT).show()
                }
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    Toast.makeText(baseContext, "${currentMode.name} Photo Saved!", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    @SuppressLint("MissingPermission")
    private fun captureVideo() {
        val videoCap = this.videoCapture ?: return
        val curRecording = activeRecording
        if (curRecording != null) {
            curRecording.stop()
            activeRecording = null
            binding.btnCapture.text = "REC"
            return
        }

        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_$name")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "DCIM/RedmiNote14Cam")
            }
        }

        val mediaStoreOutput = MediaStoreOutputOptions.Builder(
            contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(contentValues).build()

        activeRecording = videoCap.output
            .prepareRecording(this, mediaStoreOutput)
            .withAudioEnabled()
            .start(ContextCompat.getMainExecutor(this)) { recordEvent ->
                when (recordEvent) {
                    is VideoRecordEvent.Start -> binding.btnCapture.text = "STOP"
                    is VideoRecordEvent.Finalize -> {
                        binding.btnCapture.text = "REC"
                        if (!recordEvent.hasError()) {
                            Toast.makeText(baseContext, "Video Saved to Gallery!", Toast.LENGTH_SHORT).show()
                        }
                        activeRecording = null
                    }
                }
            }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                startCamera()
            } else {
                Toast.makeText(this, "Camera ane Mic permission jaruri chhe", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    companion object {
        private const val REQUEST_CODE_PERMISSIONS = 10
        private val REQUIRED_PERMISSIONS = mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        ).apply {
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }.toTypedArray()
    }
}
