package com.rohan.redmicam

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.Size
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.common.util.concurrent.ListenableFuture
import com.rohan.redmicam.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Properties
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: SharedPreferences
    private var imageCapture: ImageCapture? = null
    private var camera: Camera? = null

    private var hdrEnabled = true
    private var aspectIndex = 0
    private var capturing = false
    private var lastPhotoUri: Uri? = null

    // last tap-to-focus point (0..1 of the preview) - this is where the "subject" is
    private var tapX = 0.5f
    private var tapY = 0.5f
    private var tapTime = 0L

    // live exposure info of the preview (to know when the -4 EV frame has really settled)
    @Volatile
    private var aeProduct = 0.0
    @Volatile
    private var aeSettled = false

    private class RawFrame(val jpeg: ByteArray, val rotation: Int)

    private class AspectOption(
        val label: String,
        val viewRatio: String,   // ConstraintLayout dimensionRatio of the preview
        val use169: Boolean,     // capture with the 16:9 sensor crop
        val full: Boolean,       // preview fills the whole screen (under the bars)
        val cropAspect: Float    // extra centre crop applied to the saved photo (0 = none)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = getSharedPreferences("redmicam", MODE_PRIVATE)
        hdrEnabled = prefs.getBoolean("hdr", true)
        aspectIndex = prefs.getInt("aspect", 0).coerceIn(0, ASPECTS.size - 1)

        val perms = REQUIRED_PERMISSIONS.toMutableList()
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        if (allPermissionsGranted()) {
            startCamera()
        } else {
            ActivityCompat.requestPermissions(this, perms.toTypedArray(), REQUEST_CODE_PERMISSIONS)
        }

        binding.btnHdr.setOnClickListener {
            if (capturing) return@setOnClickListener
            hdrEnabled = !hdrEnabled
            prefs.edit().putBoolean("hdr", hdrEnabled).apply()
            updateTopButtons()
            startCamera()
        }

        binding.btnAspect.setOnClickListener {
            if (capturing) return@setOnClickListener
            aspectIndex = (aspectIndex + 1) % ASPECTS.size
            prefs.edit().putInt("aspect", aspectIndex).apply()
            updateTopButtons()
            startCamera()
        }

        binding.btnCapture.setOnClickListener {
            if (capturing) return@setOnClickListener
            if (hdrEnabled) captureHdr() else takeStandardPhoto()
        }

        binding.btnGallery.setOnClickListener { openGallery() }

        setupTapToFocus()
        updateTopButtons()

        HdrQueueState.listener = { n ->
            showQueue(n)
            refreshThumbnail()
        }
        showQueue(HdrQueueState.pending)

        // resume jobs that were left over (app/phone closed while processing)
        val leftovers = File(filesDir, "hdr_jobs").listFiles { f ->
            f.isDirectory && File(f, "meta.txt").exists()
        }
        if (!leftovers.isNullOrEmpty()) startHdrService()
    }

    override fun onResume() {
        super.onResume()
        refreshThumbnail()
    }

    override fun onDestroy() {
        HdrQueueState.listener = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- top bar / queue / gallery

    private fun updateTopButtons() {
        binding.btnHdr.text = if (hdrEnabled) "HDR" else "HDR OFF"
        binding.btnHdr.setTextColor(if (hdrEnabled) Color.parseColor("#FFD600") else Color.WHITE)
        binding.btnAspect.text = ASPECTS[aspectIndex].label
    }

    private fun showQueue(n: Int) {
        binding.tvHint.text =
            if (n > 0) "$n HDR photo background ma process thai rahya chhe - tame bija photo pade shako" else ""
        binding.progressGallery.visibility = if (n > 0) View.VISIBLE else View.GONE
    }

    private fun latestPhotoUri(): Uri? {
        val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val sel: String
        val args: Array<String>
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            sel = "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?"
            args = arrayOf("DCIM/RedmiNote14Cam%")
        } else {
            sel = "${MediaStore.Images.Media.DATA} LIKE ?"
            args = arrayOf("%/DCIM/RedmiNote14Cam/%")
        }
        return try {
            contentResolver.query(
                base,
                arrayOf(MediaStore.Images.Media._ID),
                sel,
                args,
                "${MediaStore.Images.Media.DATE_ADDED} DESC, ${MediaStore.Images.Media._ID} DESC"
            )?.use { c ->
                if (c.moveToFirst()) ContentUris.withAppendedId(base, c.getLong(0)) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun loadThumb(uri: Uri): Bitmap? =
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentResolver.loadThumbnail(uri, Size(256, 256), null)
            } else {
                val o = BitmapFactory.Options().apply { inSampleSize = 8 }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            }
        } catch (e: Exception) {
            null
        }

    private fun refreshThumbnail() {
        if (!allPermissionsGranted()) return
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                val uri = latestPhotoUri()
                Pair(uri, if (uri != null) loadThumb(uri) else null)
            }
            lastPhotoUri = result.first
            if (result.second != null) {
                binding.btnGallery.setImageBitmap(result.second)
            } else {
                binding.btnGallery.setImageDrawable(null)
            }
        }
    }

    private fun openGallery() {
        try {
            val uri = lastPhotoUri
            if (uri != null) {
                val i = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "image/*")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(i)
            } else {
                startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY))
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Gallery khuli shaki nahi", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startHdrService() {
        ContextCompat.startForegroundService(this, Intent(this, HdrService::class.java))
    }

    /** Once: ask to exclude the app from battery optimisation so phone makers do not kill HDR processing. */
    private fun askBatteryExemptionOnce() {
        try {
            if (prefs.getBoolean("asked_battery", false)) return
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (pm.isIgnoringBatteryOptimizations(packageName)) return
            prefs.edit().putBoolean("asked_battery", true).apply()
            AlertDialog.Builder(this)
                .setTitle("Background processing")
                .setMessage(
                    "HDR photo 3-5 minute background ma process thay chhe. App beech ma band na thay e mate " +
                        "'No restrictions' (battery) aapo. Xiaomi ma: Settings > Apps > Redmi Cam > Autostart ON."
                )
                .setPositiveButton("Ok") { _, _ ->
                    try {
                        startActivity(
                            Intent(
                                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                Uri.parse("package:$packageName")
                            )
                        )
                    } catch (e: Exception) {
                        // ignore
                    }
                }
                .setNegativeButton("Pachhi", null)
                .show()
        } catch (e: Exception) {
            // ignore
        }
    }

    // ---------------------------------------------------------------- tap to focus

    @SuppressLint("ClickableViewAccessibility")
    private fun setupTapToFocus() {
        binding.viewFinder.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                val cam = camera ?: return@setOnTouchListener false
                val factory = binding.viewFinder.meteringPointFactory
                val point = factory.createPoint(event.x, event.y)
                val action = FocusMeteringAction.Builder(
                    point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
                ).setAutoCancelDuration(FOCUS_HOLD_SECONDS, TimeUnit.SECONDS).build()

                // remember the subject position for the HDR background logic
                tapX = (event.x / v.width).coerceIn(0f, 1f)
                tapY = (event.y / v.height).coerceIn(0f, 1f)
                tapTime = SystemClock.elapsedRealtime()

                showFocusRing(event.x + v.left, event.y + v.top)
                try {
                    cam.cameraControl.startFocusAndMetering(action)
                } catch (e: Exception) {
                    // ignore
                }
                true
            } else {
                false
            }
        }
    }

    private fun showFocusRing(x: Float, y: Float) {
        val ring = binding.viewFocusRing
        ring.x = x - ring.width / 2f
        ring.y = y - ring.height / 2f
        ring.visibility = View.VISIBLE
        ring.scaleX = 1.5f
        ring.scaleY = 1.5f
        ring.alpha = 1.0f
        ring.animate()
            .scaleX(1.0f)
            .scaleY(1.0f)
            .setDuration(200)
            .withEndAction {
                ring.animate()
                    .alpha(0.0f)
                    .setStartDelay(800)
                    .setDuration(300)
                    .withEndAction { ring.visibility = View.INVISIBLE }
                    .start()
            }
            .start()
    }

    /** Where the subject is: the last tap (if recent) else the centre. */
    private fun subjectPoint(): Pair<Float, Float> =
        if (SystemClock.elapsedRealtime() - tapTime < FOCUS_HOLD_SECONDS * 1000L) Pair(tapX, tapY)
        else Pair(0.5f, 0.5f)

    // ---------------------------------------------------------------- camera

    private fun applyPreviewLayout(a: AspectOption) {
        val lp = binding.viewFinder.layoutParams as ConstraintLayout.LayoutParams
        lp.dimensionRatio = a.viewRatio
        if (a.full) {
            lp.topToTop = ConstraintLayout.LayoutParams.PARENT_ID
            lp.topToBottom = ConstraintLayout.LayoutParams.UNSET
        } else {
            lp.topToBottom = binding.topBar.id
            lp.topToTop = ConstraintLayout.LayoutParams.UNSET
        }
        binding.viewFinder.layoutParams = lp
        binding.topBar.setBackgroundColor(if (a.full) Color.parseColor("#66000000") else Color.BLACK)
    }

    @OptIn(ExperimentalCamera2Interop::class)
    private fun startCamera() {
        if (!allPermissionsGranted()) return
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val a = ASPECTS[aspectIndex]
            applyPreviewLayout(a)

            val ratio = if (a.use169) AspectRatio.RATIO_16_9 else AspectRatio.RATIO_4_3
            val ratioStrategy = AspectRatioStrategy(ratio, AspectRatioStrategy.FALLBACK_RULE_AUTO)

            val previewBuilder = Preview.Builder().setResolutionSelector(
                ResolutionSelector.Builder().setAspectRatioStrategy(ratioStrategy).build()
            )
            val pe = Camera2Interop.Extender(previewBuilder)
            pe.setCaptureRequestOption(
                CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON
            )
            pe.setSessionCaptureCallback(object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(
                    session: CameraCaptureSession,
                    request: CaptureRequest,
                    result: TotalCaptureResult
                ) {
                    val t = result.get(CaptureResult.SENSOR_EXPOSURE_TIME)
                    val iso = result.get(CaptureResult.SENSOR_SENSITIVITY)
                    val st = result.get(CaptureResult.CONTROL_AE_STATE)
                    if (t != null && iso != null) aeProduct = t.toDouble() * iso.toDouble()
                    aeSettled = st == null ||
                        st == CaptureResult.CONTROL_AE_STATE_CONVERGED ||
                        st == CaptureResult.CONTROL_AE_STATE_LOCKED
                }
            })
            val preview = previewBuilder.build().also {
                it.setSurfaceProvider(binding.viewFinder.surfaceProvider)
            }

            // HDR frames: about 12 MP (fast to merge, plenty of detail). HDR off: best the sensor gives.
            val resStrategy = if (hdrEnabled) {
                ResolutionStrategy(
                    if (a.use169) Size(4000, 2250) else Size(4000, 3000),
                    ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                )
            } else {
                ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY
            }
            val captureBuilder = ImageCapture.Builder()
                .setCaptureMode(
                    if (hdrEnabled) ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY
                    else ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY
                )
                .setResolutionSelector(
                    ResolutionSelector.Builder()
                        .setAspectRatioStrategy(ratioStrategy)
                        .setResolutionStrategy(resStrategy)
                        .build()
                )
            Camera2Interop.Extender(captureBuilder).setCaptureRequestOption(
                CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON
            )
            val capture = captureBuilder.build()

            provider.unbindAll()
            try {
                camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
                imageCapture = capture
            } catch (e: Exception) {
                Toast.makeText(this, "Camera start error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // ---------------------------------------------------------------- HDR capture: normal + -4 EV

    @OptIn(ExperimentalCamera2Interop::class)
    private fun lockAwb(cam: Camera, lock: Boolean): ListenableFuture<*>? {
        return try {
            val c2 = Camera2CameraControl.from(cam.cameraControl)
            if (lock) {
                c2.setCaptureRequestOptions(
                    CaptureRequestOptions.Builder()
                        .setCaptureRequestOption(CaptureRequest.CONTROL_AWB_LOCK, true)
                        .build()
                )
            } else {
                c2.clearCaptureRequestOptions()
            }
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun ListenableFuture<*>.awaitIgnoringErrors() =
        suspendCancellableCoroutine<Unit> { cont ->
            addListener({
                if (cont.isActive) cont.resume(Unit)
            }, ContextCompat.getMainExecutor(this@MainActivity))
        }

    /**
     * Waits until the preview's auto exposure has really arrived at the new exposure value
     * (exposure time x ISO stops changing and AE reports converged).
     */
    private suspend fun waitForExposureSettle(minWaitMs: Long, maxWaitMs: Long) {
        val t0 = SystemClock.elapsedRealtime()
        delay(minWaitMs)
        var prev = aeProduct
        var stable = 0
        while (SystemClock.elapsedRealtime() - t0 < maxWaitMs) {
            delay(60)
            val cur = aeProduct
            if (prev > 0.0 && abs(cur - prev) / prev < 0.04 && aeSettled) {
                stable++
                if (stable >= 3) return
            } else {
                stable = 0
            }
            prev = cur
        }
    }

    private fun setCapturing(on: Boolean) {
        capturing = on
        binding.btnCapture.alpha = if (on) 0.35f else 1f
    }

    private fun captureHdr() {
        val cap = imageCapture ?: return
        val cam = camera ?: return

        setCapturing(true)

        val st = cam.cameraInfo.exposureState
        val baseIndex = st.exposureCompensationIndex
        val step = st.exposureCompensationStep.toFloat()
        val range = st.exposureCompensationRange
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val jobDir = File(filesDir, "hdr_jobs/job_$stamp")
        val aspect = ASPECTS[aspectIndex]
        val subject = subjectPoint()

        lifecycleScope.launch {
            var normal: RawFrame? = null
            var dark: RawFrame? = null
            var usedEv = 0f
            try {
                withContext(Dispatchers.IO) { jobDir.mkdirs() }
                lockAwb(cam, true)?.awaitIgnoringErrors()

                // 1) normal photo: focused / metered on the subject (tap or auto)
                normal = captureRawFrame(cap)

                // 2) the same shot at -4 EV so the bright background is clearly visible
                if (st.isExposureCompensationSupported && step > 0f) {
                    val target = (baseIndex - (HDR_STOPS / step).roundToInt())
                        .coerceIn(range.lower, range.upper)
                    if (target < baseIndex) {
                        cam.cameraControl.setExposureCompensationIndex(target).awaitIgnoringErrors()
                        waitForExposureSettle(400, 1800)
                        dark = captureRawFrame(cap)
                        usedEv = (target - baseIndex) * step
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Capture error: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                try {
                    cam.cameraControl.setExposureCompensationIndex(baseIndex)
                } catch (e: Exception) {
                    // ignore
                }
                lockAwb(cam, false)
                waitForExposureSettle(150, 900)
                setCapturing(false)
            }

            val n = normal ?: return@launch
            val app = applicationContext
            val name = "IMG_HDR_$stamp"

            val d = dark
            if (d == null) {
                // phone refused the exposure change: just keep the normal photo
                Toast.makeText(this@MainActivity, "Aa phone ma -EV nathi mali: normal photo save thayo", Toast.LENGTH_LONG).show()
                lifecycleScope.launch(Dispatchers.IO) {
                    savePlaceholder(n, "IMG_$stamp", aspect.cropAspect)
                    withContext(Dispatchers.Main) { refreshThumbnail() }
                }
                return@launch
            }

            Toast.makeText(
                this@MainActivity,
                "Photo mali gaya (%.1f EV). HDR background ma process thase.".format(Locale.US, usedEv),
                Toast.LENGTH_SHORT
            ).show()

            // save frames + gallery placeholder + start the background job (does not block the shutter)
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    File(jobDir, "f0.jpg").writeBytes(n.jpeg)
                    File(jobDir, "f1.jpg").writeBytes(d.jpeg)
                    val placeholder = savePlaceholder(n, name, aspect.cropAspect)

                    val props = Properties()
                    props.setProperty("rotation", n.rotation.toString())
                    props.setProperty("name", name)
                    props.setProperty("uri", placeholder?.toString() ?: "")
                    props.setProperty("fx", subject.first.toString())
                    props.setProperty("fy", subject.second.toString())
                    props.setProperty("crop", aspect.cropAspect.toString())
                    props.setProperty("attempts", "0")
                    val tmp = File(jobDir, "meta.tmp")
                    tmp.outputStream().use { props.store(it, null) }
                    tmp.renameTo(File(jobDir, "meta.txt"))

                    withContext(Dispatchers.Main) {
                        ContextCompat.startForegroundService(app, Intent(app, HdrService::class.java))
                        refreshThumbnail()
                        askBatteryExemptionOnce()
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(app, "Save error: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private suspend fun captureRawFrame(capture: ImageCapture): RawFrame =
        suspendCancellableCoroutine { cont ->
            capture.takePicture(
                ContextCompat.getMainExecutor(this),
                object : ImageCapture.OnImageCapturedCallback() {
                    override fun onCaptureSuccess(image: ImageProxy) {
                        try {
                            val buffer = image.planes[0].buffer
                            val bytes = ByteArray(buffer.remaining())
                            buffer.get(bytes)
                            val rotation = image.imageInfo.rotationDegrees
                            image.close()
                            cont.resume(RawFrame(bytes, rotation))
                        } catch (e: Exception) {
                            image.close()
                            cont.resumeWithException(e)
                        }
                    }

                    override fun onError(exception: ImageCaptureException) {
                        cont.resumeWithException(exception)
                    }
                }
            )
        }

    /** The normal-exposure frame goes into the gallery at once; the service replaces it with the HDR result. */
    private fun savePlaceholder(frame: RawFrame, name: String, cropAspect: Float): Uri? {
        val upright = FrameIo.load(1, frame.rotation, cropAspect) {
            BitmapFactory.decodeByteArray(frame.jpeg, 0, frame.jpeg.size, it)
        } ?: return null
        try {
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.jpg")
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/RedmiNote14Cam")
                }
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return null
            contentResolver.openOutputStream(uri)?.use { upright.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            return uri
        } finally {
            upright.recycle()
        }
    }

    // ---------------------------------------------------------------- normal photo (HDR off)

    private fun takeStandardPhoto() {
        val capture = imageCapture ?: return
        val aspect = ASPECTS[aspectIndex]
        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())

        if (aspect.cropAspect > 0f) {
            // square photo: needs a crop, so take it in memory
            setCapturing(true)
            lifecycleScope.launch {
                try {
                    val frame = captureRawFrame(capture)
                    withContext(Dispatchers.IO) { savePlaceholder(frame, "IMG_$name", aspect.cropAspect) }
                    refreshThumbnail()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Capture Failed: ${e.message}", Toast.LENGTH_SHORT).show()
                } finally {
                    setCapturing(false)
                }
            }
            return
        }

        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_$name")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/RedmiNote14Cam")
            }
        }
        val outputOptions = ImageCapture.OutputFileOptions.Builder(
            contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            contentValues
        ).build()

        capture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onError(exc: ImageCaptureException) {
                    Toast.makeText(baseContext, "Capture Failed: ${exc.message}", Toast.LENGTH_SHORT).show()
                }

                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    refreshThumbnail()
                }
            }
        )
    }

    // ---------------------------------------------------------------- permissions

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                startCamera()
                refreshThumbnail()
            } else {
                Toast.makeText(this, "Camera permission jaruri chhe", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    companion object {
        private const val REQUEST_CODE_PERMISSIONS = 10
        private const val HDR_STOPS = 4f              // the dark frame is taken at -4 EV
        private const val FOCUS_HOLD_SECONDS = 10L    // how long a tap-to-focus point counts as "the subject"

        private val ASPECTS = listOf(
            AspectOption("3:4", "H,3:4", use169 = false, full = false, cropAspect = 0f),
            AspectOption("9:16", "H,9:16", use169 = true, full = true, cropAspect = 0f),
            AspectOption("1:1", "H,1:1", use169 = false, full = false, cropAspect = 1f)
        )

        private val REQUIRED_PERMISSIONS = mutableListOf(
            Manifest.permission.CAMERA
        ).apply {
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }.toTypedArray()
    }
}
