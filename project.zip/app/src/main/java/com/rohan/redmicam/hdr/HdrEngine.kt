package com.rohan.redmicam.hdr

import com.rohan.redmicam.hdr.HdrMath.LIN
import com.rohan.redmicam.hdr.HdrMath.smoothstep
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Background highlight recovery from a normal frame + a -4 EV frame.
 *
 * Design rules (what the user asked for):
 *  - The normal frame is the base. Every pixel that is not a bright background highlight is
 *    copied through bit-for-bit, so the subject and the rest of the photo keep the natural look.
 *  - The dark frame is used only where the normal frame is (nearly) blown out AND that area
 *    belongs to the background (sky, window, bright wall behind the subject, lamp ...). Bright
 *    blobs that sit on the subject (specular highlight, white clothes near the focus point) are
 *    protected.
 *  - Both frames are first matched geometrically (local flow) and radiometrically (measured
 *    exposure ratio + smooth local correction), merged in linear radiance, so there is no seam.
 *  - The recovered highlights are tone mapped with an edge-aware base/detail curve that only
 *    compresses values above a knee; local detail (cloud texture, window frames) is kept.
 *  - Moving things (ghosting) fall back to the normal frame automatically.
 *
 * Works on rows in chunks, so a 12 MP photo needs only a few MB of working memory on the JVM
 * heap (the two frames themselves live in the [RowSource]s).
 */
object HdrEngine {

    private const val KNEE = 0.45f          // linear value where highlight compression starts
    private const val PEAK = 0.82f         // brightest linear value recovered highlights may reach
    private const val W_LO = 0.80f         // sRGB level where the dark frame starts to be used
    private const val W_HI = 0.95f         // sRGB level where it is used fully
    private const val DETAIL_GAIN = 1.08f
    private const val DETAIL_CAP = 0.35f   // max |detail| in log units, limits halos at hard edges
    private const val MIN_RATIO = 1.6f     // below this the two frames are not really different

    private val B0 = ln(KNEE)
    private val A = ln(PEAK / KNEE)

    private fun tone(x: Float): Float =
        if (x <= B0) x else B0 + A * (1f - exp(-(x - B0) / A))

    private fun bl(
        a: FloatArray, i00: Int, i01: Int, i10: Int, i11: Int,
        w00: Float, w01: Float, w10: Float, w11: Float
    ): Float = a[i00] * w00 + a[i01] * w01 + a[i10] * w10 + a[i11] * w11

    fun run(
        n: RowSource,
        u: RowSource,
        opt: HdrOptions,
        sink: RowSink,
        progress: (Float, String) -> Unit = { _, _ -> },
        cancelled: () -> Boolean = { false }
    ): HdrReport {
        val rep = HdrReport()
        val w = n.width
        val h = n.height
        require(u.width == w && u.height == h) { "frame sizes differ" }
        fun check() {
            if (cancelled()) throw HdrCancelled()
        }

        // ------------------------------------------------------------ 1. low resolution copies
        progress(0.01f, "Reading frames")
        val d = max(1, ceil(max(w, h) / 800.0).toInt())
        val lw = (w + d - 1) / d
        val lh = (h + d - 1) / d
        val np = lw * lh
        val nl = Array(3) { FloatArray(np) }
        val ul = Array(3) { FloatArray(np) }
        val cnt = FloatArray(np)
        val chunk = d * 16
        val bufN = IntArray(w * chunk)
        val bufU = IntArray(w * chunk)
        var blown = 0L

        if (true) {
            var y = 0
            while (y < h) {
                check()
                val rows = min(chunk, h - y)
                n.readRows(y, rows, bufN)
                u.readRows(y, rows, bufU)
                for (r in 0 until rows) {
                    val cy = ((y + r) / d) * lw
                    val base = r * w
                    for (x in 0 until w) {
                        val pn = bufN[base + x]
                        val pu = bufU[base + x]
                        val cell = cy + x / d
                        val nr = (pn shr 16) and 255
                        val ng = (pn shr 8) and 255
                        val nb = pn and 255
                        nl[0][cell] += LIN[nr]
                        nl[1][cell] += LIN[ng]
                        nl[2][cell] += LIN[nb]
                        ul[0][cell] += LIN[(pu shr 16) and 255]
                        ul[1][cell] += LIN[(pu shr 8) and 255]
                        ul[2][cell] += LIN[pu and 255]
                        cnt[cell] += 1f
                        if (nr >= 242 || ng >= 242 || nb >= 242) blown++
                    }
                }
                y += rows
                progress(0.01f + 0.09f * y / h, "Reading frames")
            }
        }
        for (i in 0 until np) {
            val c = 1f / max(cnt[i], 1f)
            for (k in 0..2) {
                nl[k][i] *= c
                ul[k][i] *= c
            }
        }
        rep.blownPercent = 100f * blown / (w.toLong() * h)

        fun passthrough(note: String): HdrReport {
            var y = 0
            while (y < h) {
                val rows = min(chunk, h - y)
                n.readRows(y, rows, bufN)
                sink.writeRows(y, rows, bufN)
                y += rows
            }
            rep.note = note
            progress(1f, note)
            return rep
        }

        if (rep.blownPercent < 0.04f) return passthrough("No blown highlights - photo kept as is")

        // ------------------------------------------------------------ 2. alignment
        progress(0.12f, "Aligning frames")
        val yN = FloatArray(np) { HdrMath.lum(nl[0][it], nl[1][it], nl[2][it]) }
        val yU = FloatArray(np) { HdrMath.lum(ul[0][it], ul[1][it], ul[2][it]) }
        val flow = HdrAlign.estimate(yN, yU, lw, lh)
        check()

        val uw = Array(3) { FloatArray(np) }
        val inside = FloatArray(np)
        for (y in 0 until lh) for (x in 0 until lw) {
            val i = y * lw + x
            val sx = x + flow.fx[i]
            val sy = y + flow.fy[i]
            inside[i] = if (sx >= 0f && sy >= 0f && sx <= lw - 1f && sy <= lh - 1f) 1f else 0f
            for (k in 0..2) uw[k][i] = HdrMath.sample(ul[k], lw, lh, sx, sy)
        }

        // ------------------------------------------------------------ 3. exposure ratio
        progress(0.2f, "Matching exposure")
        val yUw = FloatArray(np) { HdrMath.lum(uw[0][it], uw[1][it], uw[2][it]) }
        val stride = max(1, np / 200000)
        val cap = np / stride + 1
        val rs = Array(3) { FloatArray(cap) }
        val rc = IntArray(3)
        for (i in 0 until np step stride) {
            if (inside[i] <= 0f) continue
            val mxN = max(nl[0][i], max(nl[1][i], nl[2][i]))
            val mxU = max(uw[0][i], max(uw[1][i], uw[2][i]))
            if (yN[i] < 0.10f || yN[i] > 0.62f || mxN > 0.80f || yUw[i] < 0.006f || mxU > 0.92f) continue
            for (k in 0..2) {
                if (nl[k][i] >= 0.02f && uw[k][i] >= 0.003f) rs[k][rc[k]++] = nl[k][i] / uw[k][i]
            }
        }
        val prior = Math.pow(2.0, opt.nominalStops.toDouble()).toFloat()
        val kc = FloatArray(3) { if (rc[it] >= 300) HdrMath.median(rs[it], rc[it]) else 0f }
        var kL = if (kc.all { it > 0f }) HdrMath.lum(kc[0], kc[1], kc[2]) else 0f
        var note = ""
        // fall back to the nominal ratio only if it could not be measured at all (or is absurd);
        // a small measured ratio means the exposure compensation did not really apply
        if (kL <= 0f || kL > prior * 3f) {
            kL = prior
            note = "ratio fallback"
        }
        for (k in 0..2) {
            kc[k] = kL   // brightness scale only: colours of the recovered area stay as the dark frame saw them
        }
        rep.stops = (ln(kL.toDouble()) / ln(2.0)).toFloat()
        if (kL < MIN_RATIO) return passthrough("Frames have no real exposure difference - photo kept as is")

        // smooth local correction of the ratio (the phone's own tone mapping is not perfectly global)
        val lnr = FloatArray(np)
        val wgt = FloatArray(np)
        for (i in 0 until np) {
            if (inside[i] <= 0f) continue
            val mxN = max(nl[0][i], max(nl[1][i], nl[2][i]))
            val mxU = max(uw[0][i], max(uw[1][i], uw[2][i]))
            val yAdj = HdrMath.lum(kc[0] * uw[0][i], kc[1] * uw[1][i], kc[2] * uw[2][i])
            if (yN[i] < 0.05f || yN[i] > 0.85f || mxN > 0.88f || yAdj < 0.004f || mxU > 0.95f) continue
            lnr[i] = ln(yN[i] / yAdj)
            wgt[i] = 1f
        }
        // ignore strong edges: a 1px alignment error there looks like a brightness change
        val edge = FloatArray(np)
        for (y in 1 until lh - 1) for (x in 1 until lw - 1) {
            val i = y * lw + x
            val gx = ln(max(yN[i + 1], 1e-3f) / max(yN[i - 1], 1e-3f))
            val gy = ln(max(yN[i + lw], 1e-3f) / max(yN[i - lw], 1e-3f))
            if (abs(gx) > 0.12f || abs(gy) > 0.12f) edge[i] = 1f
        }
        val edgeD = HdrMath.dilate(edge, lw, lh, 2)
        for (i in 0 until np) if (edgeD[i] > 0f) wgt[i] = 0f
        val (m1, c1) = HdrMath.normBox(lnr, wgt, lw, lh, max(4, lw / 12))
        val (m2, c2) = HdrMath.normBox(lnr, wgt, lw, lh, max(8, lw / 4))
        val (m3, c3) = HdrMath.normBox(lnr, wgt, lw, lh, lw)
        var lnRho = FloatArray(np) {
            when {
                c1[it] >= 0.01f -> m1[it]
                c2[it] >= 0.003f -> m2[it]
                c3[it] > 1e-5f -> m3[it]
                else -> 0f
            }.coerceIn(-0.4f, 0.4f)
        }
        lnRho = HdrMath.box(HdrMath.box(lnRho, lw, lh, max(2, lw / 40)), lw, lh, max(2, lw / 40))

        // ------------------------------------------------------------ 4. ghost map
        progress(0.25f, "Checking for movement")
        // compare local means (not single pixels) so thin edges with a 1px alignment error do not look like motion
        val yAdjF = FloatArray(np) { HdrMath.lum(kc[0] * uw[0][it], kc[1] * uw[1][it], kc[2] * uw[2][it]) }
        val (mN, _) = HdrMath.normBox(yN, wgt, lw, lh, 2)
        val (mU, _) = HdrMath.normBox(yAdjF, wgt, lw, lh, 2)
        val err = FloatArray(np) {
            if (wgt[it] > 0f && mN[it] > 1e-4f && mU[it] > 1e-4f) abs(ln(mN[it] / mU[it]) - lnRho[it]) else 0f
        }
        val (e1, ec1) = HdrMath.normBox(err, wgt, lw, lh, 3)
        val (e2, ec2) = HdrMath.normBox(err, wgt, lw, lh, 12)
        var ghost = FloatArray(np) {
            val e = when {
                ec1[it] >= 0.12f -> e1[it]
                ec2[it] >= 0.02f -> e2[it]
                else -> 0f
            }
            smoothstep(e, 0.30f, 0.80f)
        }
        ghost = HdrMath.box(HdrMath.dilate(ghost, lw, lh, 2), lw, lh, 1)

        // ------------------------------------------------------------ 5. background / subject
        progress(0.3f, "Finding background")
        val mx = FloatArray(np) { HdrMath.encode01(max(nl[0][it], max(nl[1][it], nl[2][it]))) }
        val label = IntArray(np) { -1 }
        val stack = IntArray(np)
        val area = ArrayList<Int>()
        val border = ArrayList<Boolean>()
        val dist = ArrayList<Float>()
        val fpx = opt.focusX * lw
        val fpy = opt.focusY * lh
        val norm = min(lw, lh).toFloat()
        for (s in 0 until np) {
            if (label[s] != -1 || mx[s] < 0.90f) continue
            val id = area.size
            var sp = 0
            stack[sp++] = s
            label[s] = id
            var a = 0
            var touch = false
            var dmin = Float.MAX_VALUE
            while (sp > 0) {
                val i = stack[--sp]
                a++
                val x = i % lw
                val y = i / lw
                if (x == 0 || y == 0 || x == lw - 1 || y == lh - 1) touch = true
                val dx = x - fpx
                val dy = y - fpy
                val dd = sqrt(dx * dx + dy * dy)
                if (dd < dmin) dmin = dd
                if (x > 0 && label[i - 1] == -1 && mx[i - 1] >= 0.90f) { label[i - 1] = id; stack[sp++] = i - 1 }
                if (x < lw - 1 && label[i + 1] == -1 && mx[i + 1] >= 0.90f) { label[i + 1] = id; stack[sp++] = i + 1 }
                if (y > 0 && label[i - lw] == -1 && mx[i - lw] >= 0.90f) { label[i - lw] = id; stack[sp++] = i - lw }
                if (y < lh - 1 && label[i + lw] == -1 && mx[i + lw] >= 0.90f) { label[i + lw] = id; stack[sp++] = i + lw }
            }
            area.add(a)
            border.add(touch)
            dist.add(dmin / norm)
        }
        // how many pixels of each bright area really have MORE light in the dark frame than the
        // normal frame could hold (i.e. were clipped). Bright-but-not-clipped areas are left alone.
        val high = IntArray(area.size)
        for (i in 0 until np) {
            val l = label[i]
            if (l >= 0 && yAdjF[i] * exp(lnRho[i]) >= 1.3f * max(yN[i], 1e-3f)) high[l]++
        }
        val isBg = BooleanArray(area.size) { c ->
            val frac = area[c] / np.toFloat()
            if (high[c] < 0.2f * area[c]) return@BooleanArray false
            when {
                frac >= 0.004f -> true                 // big bright area = sky / window / wall behind
                border[c] -> frac >= 0.0008f           // thin bright strip at the image border
                else -> dist[c] >= 0.30f               // small blob: subject highlight if near the focus point
            }
        }
        val s0 = FloatArray(np) { if (label[it] >= 0 && isBg[label[it]]) 1f else 0f }
        val sMask = HdrMath.box(HdrMath.dilate(s0, lw, lh, 5), lw, lh, 3)

        // ------------------------------------------------------------ 6. low-res merge + base layer
        progress(0.35f, "Planning highlight recovery")
        // information gain: only places where the dark frame holds clearly MORE light than the
        // normal frame could store are touched (a white shirt that is bright but not clipped has
        // gain ~1 and stays exactly as the camera made it). Smoothed so it never makes a contour.
        val gain0 = FloatArray(np) {
            val q = yAdjF[it] * exp(lnRho[it]) / max(yN[it], 1e-3f)
            smoothstep(q, 1.15f, 1.6f)
        }
        val gainS = HdrMath.box(HdrMath.box(gain0, lw, lh, 2), lw, lh, 2)
        val gate = FloatArray(np) { sMask[it] * (1f - ghost[it]) * inside[it] }
        val lg = FloatArray(np)
        var recovered = 0
        for (i in 0 until np) {
            val a = gate[i] * max(gainS[i], smoothstep(mx[i], 0.975f, 0.99f)) * smoothstep(mx[i], W_LO, W_HI)
            if (a > 0.5f) recovered++
            val rho = exp(lnRho[i])
            val rm0 = nl[0][i] + a * (kc[0] * rho * uw[0][i] - nl[0][i])
            val rm1 = nl[1][i] + a * (kc[1] * rho * uw[1][i] - nl[1][i])
            val rm2 = nl[2][i] + a * (kc[2] * rho * uw[2][i] - nl[2][i])
            lg[i] = ln(max(HdrMath.lum(rm0, rm1, rm2), 1e-4f))
        }
        rep.recoveredPercent = 100f * recovered / np
        if (rep.recoveredPercent < 0.02f) {
            return passthrough("Bright areas belong to the subject - photo kept as is")
        }
        val baseLow = HdrMath.guidedSelf(lg, lw, lh, max(3, lw / 50), 0.02f)
        check()

        // ------------------------------------------------------------ 7. full resolution pass
        val fxD = FloatArray(np) { flow.fx[it] * d }
        val fyD = FloatArray(np) { flow.fy[it] * d }
        var fyMin = 0f
        var fyMax = 0f
        for (v in fyD) {
            if (v < fyMin) fyMin = v
            if (v > fyMax) fyMax = v
        }
        val marginUp = ceil(-fyMin).toInt() + 3
        val marginDn = ceil(fyMax).toInt() + 3
        val bufW = IntArray(w * (chunk + marginUp + marginDn))
        val bufOut = IntArray(w * chunk)

        val xi0 = IntArray(w)
        val xi1 = IntArray(w)
        val xf = FloatArray(w)
        for (x in 0 until w) {
            val fx = ((x + 0.5f) / d - 0.5f).coerceIn(0f, (lw - 1).toFloat())
            val i0 = fx.toInt()
            xi0[x] = i0
            xi1[x] = min(i0 + 1, lw - 1)
            xf[x] = fx - i0
        }
        val kR = kc[0]
        val kG = kc[1]
        val kB = kc[2]

        var y0 = 0
        while (y0 < h) {
            check()
            val rows = min(chunk, h - y0)
            n.readRows(y0, rows, bufN)
            System.arraycopy(bufN, 0, bufOut, 0, rows * w)
            var winLoaded = false
            var winY0 = 0
            var winY1 = 0

            for (r in 0 until rows) {
                val y = y0 + r
                val fyl = ((y + 0.5f) / d - 0.5f).coerceIn(0f, (lh - 1).toFloat())
                val yi0 = fyl.toInt()
                val yi1 = min(yi0 + 1, lh - 1)
                val yf = fyl - yi0
                val row0 = yi0 * lw
                val row1 = yi1 * lw

                for (x in 0 until w) {
                    val idx = r * w + x
                    val p = bufN[idx]
                    val r8 = (p shr 16) and 255
                    val g8 = (p shr 8) and 255
                    val b8 = p and 255
                    val m8 = max(r8, max(g8, b8))
                    if (m8 <= 204) continue
                    val wN = smoothstep(m8 / 255f, W_LO, W_HI)
                    if (wN < 0.003f) continue

                    val a = xf[x]
                    val i00 = row0 + xi0[x]
                    val i01 = row0 + xi1[x]
                    val i10 = row1 + xi0[x]
                    val i11 = row1 + xi1[x]
                    val w00 = (1f - a) * (1f - yf)
                    val w01 = a * (1f - yf)
                    val w10 = (1f - a) * yf
                    val w11 = a * yf

                    val gt = bl(gate, i00, i01, i10, i11, w00, w01, w10, w11)
                    // truly clipped pixels always carry recoverable information; for the rest the
                    // smooth information gain decides (keeps bright-but-valid subject areas as shot)
                    val gi = max(bl(gainS, i00, i01, i10, i11, w00, w01, w10, w11),
                        smoothstep(m8 / 255f, 0.975f, 0.99f))
                    val alpha = gt * gi * wN
                    if (alpha < 0.004f) continue

                    val sx = x + bl(fxD, i00, i01, i10, i11, w00, w01, w10, w11)
                    val sy = y + bl(fyD, i00, i01, i10, i11, w00, w01, w10, w11)
                    if (sx < 0f || sy < 0f || sx > w - 1f || sy > h - 1f) continue

                    if (!winLoaded) {
                        winY0 = max(0, y0 - marginUp)
                        winY1 = min(h, y0 + rows + marginDn)
                        u.readRows(winY0, winY1 - winY0, bufW)
                        winLoaded = true
                    }

                    // bilinear sample of the dark frame (linear light)
                    val sxi = sx.toInt()
                    val sxf = sx - sxi
                    val sx1 = min(sxi + 1, w - 1)
                    val syc = sy.coerceIn(winY0.toFloat(), (winY1 - 1).toFloat())
                    val syi = syc.toInt()
                    val syf = syc - syi
                    val sy1 = min(syi + 1, winY1 - 1)
                    val q00 = bufW[(syi - winY0) * w + sxi]
                    val q01 = bufW[(syi - winY0) * w + sx1]
                    val q10 = bufW[(sy1 - winY0) * w + sxi]
                    val q11 = bufW[(sy1 - winY0) * w + sx1]
                    val c00 = (1f - sxf) * (1f - syf)
                    val c01 = sxf * (1f - syf)
                    val c10 = (1f - sxf) * syf
                    val c11 = sxf * syf
                    val ur = LIN[(q00 shr 16) and 255] * c00 + LIN[(q01 shr 16) and 255] * c01 +
                        LIN[(q10 shr 16) and 255] * c10 + LIN[(q11 shr 16) and 255] * c11
                    val ug = LIN[(q00 shr 8) and 255] * c00 + LIN[(q01 shr 8) and 255] * c01 +
                        LIN[(q10 shr 8) and 255] * c10 + LIN[(q11 shr 8) and 255] * c11
                    val ub = LIN[q00 and 255] * c00 + LIN[q01 and 255] * c01 +
                        LIN[q10 and 255] * c10 + LIN[q11 and 255] * c11

                    // a nearly clipped dark-frame pixel has unreliable colour (channels clip at
                    // different levels) -> make it neutral, keep only its brightness
                    var ur2 = ur
                    var ug2 = ug
                    var ub2 = ub
                    val umx = max(ur, max(ug, ub))
                    val cl = smoothstep(umx, 0.95f, 0.995f)
                    if (cl > 0f) {
                        val yu = HdrMath.lum(ur, ug, ub)
                        ur2 = ur + cl * (yu - ur)
                        ug2 = ug + cl * (yu - ug)
                        ub2 = ub + cl * (yu - ub)
                    }
                    val rho = exp(bl(lnRho, i00, i01, i10, i11, w00, w01, w10, w11))
                    val rn = LIN[r8]
                    val gn = LIN[g8]
                    val bn = LIN[b8]

                    // merged radiance (normal-frame scale, can be > 1)
                    val rm = rn + alpha * (kR * rho * ur2 - rn)
                    val gm = gn + alpha * (kG * rho * ug2 - gn)
                    val bm = bn + alpha * (kB * rho * ub2 - bn)
                    val ym = max(HdrMath.lum(rm, gm, bm), 1e-4f)
                    val lgp = ln(ym)

                    // edge aware base / detail tone curve (only above the knee)
                    var base = bl(baseLow, i00, i01, i10, i11, w00, w01, w10, w11)
                    base = base.coerceIn(lgp - DETAIL_CAP, lgp + DETAIL_CAP)
                    val yo = exp(tone(base) + DETAIL_GAIN * (lgp - base))
                    val sc = yo / ym
                    val sat = 1.08f + 0.12f * (base - B0).coerceIn(0f, 1f)
                    var cr = max(yo + (rm * sc - yo) * sat, 0f)
                    var cg = max(yo + (gm * sc - yo) * sat, 0f)
                    var cb = max(yo + (bm * sc - yo) * sat, 0f)
                    val mc = max(cr, max(cg, cb))
                    if (mc > PEAK) {
                        val s = (PEAK + (1f - PEAK) * (1f - exp(-(mc - PEAK) / (1f - PEAK)))) / mc
                        cr *= s; cg *= s; cb *= s
                    }

                    // blend with the untouched normal frame
                    val orr = rn + alpha * (cr - rn)
                    val og = gn + alpha * (cg - gn)
                    val ob = bn + alpha * (cb - bn)
                    bufOut[idx] = (0xFF shl 24) or
                        (quant(HdrMath.encode(orr), x, y, 0) shl 16) or
                        (quant(HdrMath.encode(og), x, y, 1) shl 8) or
                        quant(HdrMath.encode(ob), x, y, 2)
                }
            }
            sink.writeRows(y0, rows, bufOut)
            y0 += rows
            progress(0.4f + 0.58f * y0 / h, "Recovering highlights")
        }
        rep.merged = true
        rep.note = if (note.isEmpty()) "ok" else note
        progress(1f, "Done")
        return rep
    }

    /** Rounds a 0..255 float with triangular dither so smooth skies do not band. */
    private fun quant(v: Float, x: Int, y: Int, c: Int): Int {
        var hsh = x * 374761393 + y * 668265263 + c * 1442695041
        hsh = (hsh xor (hsh ushr 13)) * 1274126177
        val n1 = ((hsh xor (hsh ushr 16)) and 0xFFFF) / 65536f
        hsh = (hsh xor (hsh ushr 15)) * 1103515245 + 12345
        val n2 = ((hsh xor (hsh ushr 16)) and 0xFFFF) / 65536f
        val o = (v + (n1 + n2 - 1f) * 0.75f + 0.5f).toInt()
        return if (o < 0) 0 else if (o > 255) 255 else o
    }
}
