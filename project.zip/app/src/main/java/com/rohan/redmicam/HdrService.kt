package com.rohan.redmicam

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.provider.MediaStore
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.rohan.redmicam.hdr.HdrEngine
import com.rohan.redmicam.hdr.HdrOptions
import java.io.File
import java.io.FileOutputStream
import java.util.Collections
import java.util.Properties
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/** Tiny shared state so the camera screen can show how many HDR photos are still processing. */
object HdrQueueState {
    @Volatile
    var pending: Int = 0

    @Volatile
    var listener: ((Int) -> Unit)? = null

    private val handler = Handler(Looper.getMainLooper())

    fun update(n: Int) {
        pending = n
        val l = listener
        if (l != null) handler.post { l(n) }
    }
}

/**
 * Foreground service that processes HDR jobs one after another in the background, so the camera
 * stays free for the next photo and processing survives the app being minimised or swiped away.
 *
 * A job = folder  files/hdr_jobs/job_xxx  with
 *   f0.jpg  normal frame (focused on the subject)
 *   f1.jpg  -4 EV frame
 *   meta.txt  rotation, name, gallery uri, focus point, crop, attempts
 * Jobs live on disk, so they continue after the service / process is restarted.
 */
class HdrService : Service() {

    private val executor = Executors.newSingleThreadExecutor()
    private val queued: MutableSet<String> = Collections.synchronizedSet(HashSet<String>())
    private val pending = AtomicInteger(0)
    private val doneCounter = AtomicInteger(0)
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var lastPct = -1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(pending.get(), -1, ""), type)
        scanJobs()
        return START_STICKY
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun scanJobs() {
        val root = File(filesDir, "hdr_jobs")
        val dirs = root.listFiles { f -> f.isDirectory && File(f, "meta.txt").exists() }
            ?.sortedBy { it.name }
            ?: emptyList()
        for (d in dirs) {
            if (queued.add(d.name)) {
                HdrQueueState.update(pending.incrementAndGet())
                executor.execute { processJob(d) }
            }
        }
        updateNotification(-1, "")
        if (pending.get() == 0) finishService()
    }

    private fun finishService() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun processJob(dir: File) {
        // normal priority (not "background"): the foreground service keeps us alive, and the
        // background cgroup would slow the job down a lot when the screen is off
        Process.setThreadPriority(Process.THREAD_PRIORITY_LESS_FAVORABLE)
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "redmicam:hdr")
        wl.acquire(15 * 60 * 1000L)
        var n: Bitmap? = null
        var u: Bitmap? = null
        var out: Bitmap? = null
        try {
            val metaFile = File(dir, "meta.txt")
            val props = Properties()
            metaFile.inputStream().use { props.load(it) }
            val rotation = props.getProperty("rotation", "0").toIntOrNull() ?: 0
            val name = props.getProperty("name", "IMG_HDR")
            val uriStr = props.getProperty("uri", "")
            val focusX = props.getProperty("fx", "0.5").toFloatOrNull() ?: 0.5f
            val focusY = props.getProperty("fy", "0.5").toFloatOrNull() ?: 0.5f
            val crop = props.getProperty("crop", "0").toFloatOrNull() ?: 0f
            val attempts = props.getProperty("attempts", "0").toIntOrNull() ?: 0

            // a job that already crashed the process twice is dropped (the normal photo stays in the gallery)
            if (attempts >= 2) return
            props.setProperty("attempts", (attempts + 1).toString())
            val tmp = File(dir, "meta.tmp")
            tmp.outputStream().use { props.store(it, null) }
            tmp.renameTo(metaFile)

            val sample = if (attempts >= 1) 2 else 1   // second try: half resolution (less memory)
            val f0 = File(dir, "f0.jpg")
            val f1 = File(dir, "f1.jpg")
            if (!f0.exists() || !f1.exists()) return

            setStage(0, "Photos load thai rahya chhe")
            n = FrameIo.load(sample, rotation, crop) { BitmapFactory.decodeFile(f0.absolutePath, it) }
            u = FrameIo.load(sample, rotation, crop) { BitmapFactory.decodeFile(f1.absolutePath, it) }
            if (n == null || u == null) return
            if (u.width != n.width || u.height != n.height) {
                val s = Bitmap.createScaledBitmap(u, n.width, n.height, true)
                if (s !== u) u.recycle()
                u = s
            }

            out = Bitmap.createBitmap(n.width, n.height, Bitmap.Config.ARGB_8888)
            val report = HdrEngine.run(
                BitmapRowSource(n),
                BitmapRowSource(u),
                HdrOptions(focusX, focusY, 4f),
                BitmapRowSink(out),
                progress = { p, label -> setStage((p * 100).toInt(), label) },
                cancelled = { Thread.currentThread().isInterrupted }
            )
            Log.i(TAG, "HDR result: $report")
            n.recycle(); n = null
            u.recycle(); u = null

            if (report.merged) {
                setStage(99, "Gallery ma save thai rahyu chhe")
                val result = File(dir, "result.jpg")
                FileOutputStream(result).use { out.compress(Bitmap.CompressFormat.JPEG, 97, it) }
                saveResult(result, name, uriStr)
                notifyDone("HDR photo taiyar", "Background ni light recover thai (${"%.1f".format(report.stops)} EV)")
            } else {
                notifyDone("Photo taiyar", "Aa photo ma HDR ni jarur na hati: ${report.note}")
            }
        } catch (t: Throwable) {
            Log.e(TAG, "HDR job failed", t)
        } finally {
            n?.recycle()
            u?.recycle()
            out?.recycle()
            if (wl.isHeld) wl.release()
            dir.deleteRecursively()
            queued.remove(dir.name)
            HdrQueueState.update(pending.decrementAndGet())
            mainHandler.post { onJobFinished() }
        }
    }

    private fun setStage(pct: Int, label: String) {
        if (pct == lastPct) return
        lastPct = pct
        updateNotification(pct, label)
    }

    private fun onJobFinished() {
        lastPct = -1
        updateNotification(-1, "")
        if (pending.get() == 0) finishService()
    }

    /** Replace the placeholder photo in the gallery with the final HDR photo (same file, same name). */
    private fun saveResult(result: File, name: String, uriStr: String) {
        var saved = false
        if (uriStr.isNotEmpty()) {
            val uri = Uri.parse(uriStr)
            try {
                contentResolver.openOutputStream(uri, "wt")?.use { os ->
                    result.inputStream().use { it.copyTo(os) }
                    saved = true
                }
            } catch (e: Exception) {
                saved = false
            }
        }
        if (!saved) {
            // placeholder was deleted or missing: save as a new photo
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.jpg")
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/RedmiNote14Cam")
                }
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { os ->
                    result.inputStream().use { it.copyTo(os) }
                }
            }
        }
    }

    // ------------------------------------------------------------ notifications

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "HDR processing", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(DONE_CHANNEL_ID, "HDR ready", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun openAppIntent(): PendingIntent =
        PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun buildNotification(n: Int, pct: Int, label: String): Notification {
        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setContentTitle("HDR processing")
            .setContentIntent(openAppIntent())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
        val head = if (n > 0) "$n photo background ma process thai rahya chhe" else "Taiyar thai rahyu chhe..."
        if (pct in 0..100) {
            b.setContentText(if (label.isNotEmpty()) "$label  ($pct%)  -  $head" else head)
            b.setProgress(100, pct, false)
        } else {
            b.setContentText(head)
            b.setProgress(0, 0, true)
        }
        return b.build()
    }

    private fun updateNotification(pct: Int, label: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(pending.get(), pct, label))
    }

    private fun notifyDone(title: String, text: String) {
        val n = NotificationCompat.Builder(this, DONE_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openAppIntent())
            .setAutoCancel(true)
            .build()
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(DONE_NOTIF_BASE + doneCounter.incrementAndGet(), n)
    }

    companion object {
        private const val TAG = "HdrService"
        private const val CHANNEL_ID = "hdr_processing"
        private const val DONE_CHANNEL_ID = "hdr_done"
        private const val NOTIF_ID = 1
        private const val DONE_NOTIF_BASE = 1000
    }
}
