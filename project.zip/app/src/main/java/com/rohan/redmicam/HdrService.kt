package com.rohan.redmicam

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import android.provider.MediaStore
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.File
import java.util.Collections
import java.util.Properties
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/** Tiny shared state so the camera screen can show how many HDR photos are still processing. */
object HdrQueueState {
    @Volatile
    var pending: Int = 0

    @Volatile
    var listener: ((Int) -> Unit)? = null

    private val handler = Handler(Looper.getMainLooper())

    fun update(n: Int) {
        pending = n
        val l = listener
        if (l != null) handler.post { l(n) }
    }
}

/**
 * Foreground service that processes HDR jobs one after another in the background.
 * A job = folder  files/hdr_jobs/job_xxx  with f0.jpg (normal), f1.jpg, f2.jpg (darker) and meta.txt.
 * Jobs survive app/service restarts because they live on disk.
 */
class HdrService : Service() {

    private val executor = Executors.newSingleThreadExecutor()
    private val queued: MutableSet<String> = Collections.synchronizedSet(HashSet<String>())
    private val pending = AtomicInteger(0)
    private val doneCounter = AtomicInteger(0)
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(pending.get()), type)
        scanJobs()
        return START_STICKY
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun scanJobs() {
        val root = File(filesDir, "hdr_jobs")
        val dirs = root.listFiles { f -> f.isDirectory && File(f, "meta.txt").exists() }
            ?.sortedBy { it.name }
            ?: emptyList()
        for (d in dirs) {
            if (queued.add(d.name)) {
                HdrQueueState.update(pending.incrementAndGet())
                executor.execute { processJob(d) }
            }
        }
        updateNotification()
        if (pending.get() == 0) finishService()
    }

    private fun finishService() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun processJob(dir: File) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
        val bitmaps = ArrayList<Bitmap>()
        try {
            val props = Properties()
            File(dir, "meta.txt").inputStream().use { props.load(it) }
            val rotation = props.getProperty("rotation", "0").toIntOrNull() ?: 0
            val frames = props.getProperty("frames", "0").toIntOrNull() ?: 0
            val name = props.getProperty("name", "IMG_HDR")
            val uriStr = props.getProperty("uri", "")

            for (i in 0 until frames) {
                val f = File(dir, "f$i.jpg")
                if (!f.exists()) continue
                val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
                val decoded = BitmapFactory.decodeFile(f.absolutePath, opts) ?: continue
                val upright = if (rotation != 0) {
                    val m = Matrix().apply { postRotate(rotation.toFloat()) }
                    val r = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, m, true)
                    if (r !== decoded) decoded.recycle()
                    r
                } else {
                    decoded
                }
                bitmaps.add(upright)
            }
            if (bitmaps.isEmpty()) return

            val merged = HdrProcessor.merge(bitmaps)
            try {
                saveResult(merged, name, uriStr)
            } finally {
                merged.recycle()
            }
            notifyDone()
        } catch (t: Throwable) {
            Log.e(TAG, "HDR job failed", t)
        } finally {
            for (b in bitmaps) b.recycle()
            dir.deleteRecursively()
            queued.remove(dir.name)
            HdrQueueState.update(pending.decrementAndGet())
            mainHandler.post { onJobFinished() }
        }
    }

    private fun onJobFinished() {
        updateNotification()
        if (pending.get() == 0) finishService()
    }

    /** Replace the placeholder photo in the gallery with the final HDR photo. */
    private fun saveResult(bitmap: Bitmap, name: String, uriStr: String) {
        var saved = false
        if (uriStr.isNotEmpty()) {
            val uri = Uri.parse(uriStr)
            try {
                contentResolver.openOutputStream(uri, "wt")?.use { os ->
                    saved = bitmap.compress(Bitmap.CompressFormat.JPEG, 97, os)
                }
                if (saved) {
                    val cv = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.jpg")
                    }
                    contentResolver.update(uri, cv, null, null)
                }
            } catch (e: Exception) {
                saved = false
            }
        }
        if (!saved) {
            // placeholder was deleted or missing: save as a new photo
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.jpg")
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/RedmiNote14Cam")
                }
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { os ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 97, os)
                }
            }
        }
    }

    // ------------------------------------------------------------ notifications

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "HDR processing", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(n: Int): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setContentTitle("HDR processing")
            .setContentText(
                if (n > 0) "$n photo background ma process thai rahya chhe" else "Taiyar thai rahyu chhe..."
            )
            .setProgress(0, 0, true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()

    private fun updateNotification() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(pending.get()))
    }

    private fun notifyDone() {
        val n = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setContentTitle("HDR photo taiyar")
            .setContentText("Gallery ma final HDR photo save thayo")
            .setAutoCancel(true)
            .build()
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(DONE_NOTIF_BASE + doneCounter.incrementAndGet(), n)
    }

    companion object {
        private const val TAG = "HdrService"
        private const val CHANNEL_ID = "hdr_processing"
        private const val NOTIF_ID = 1
        private const val DONE_NOTIF_BASE = 1000
    }
}
