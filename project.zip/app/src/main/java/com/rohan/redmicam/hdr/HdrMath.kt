package com.rohan.redmicam.hdr

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/** Small numeric helpers: colour tables, box / guided filters, median. */
internal object HdrMath {

    // ---------------------------------------------------------------- colour tables

    val LIN = FloatArray(256) { i ->
        val c = i / 255f
        if (c <= 0.04045f) c / 12.92f else ((c + 0.055f) / 1.055f).pow(2.4f)
    }

    private const val ENC_N = 4096
    private val ENC = FloatArray(ENC_N + 2) { i ->
        val l = min(i, ENC_N) / ENC_N.toFloat()
        val c = if (l <= 0.0031308f) l * 12.92f else 1.055f * l.pow(1f / 2.4f) - 0.055f
        c * 255f
    }

    /** Linear 0..1 -> sRGB code value 0..255 as float (not rounded). */
    fun encode(v: Float): Float {
        val t = (if (v < 0f) 0f else if (v > 1f) 1f else v) * ENC_N
        val i = t.toInt()
        val f = t - i
        return ENC[i] + (ENC[i + 1] - ENC[i]) * f
    }

    /** Linear 0..1 -> sRGB 0..1. */
    fun encode01(v: Float): Float = encode(v) * (1f / 255f)

    // ---------------------------------------------------------------- scalar helpers

    fun smoothstep(x: Float, e0: Float, e1: Float): Float {
        val t = ((x - e0) / (e1 - e0)).let { if (it < 0f) 0f else if (it > 1f) 1f else it }
        return t * t * (3f - 2f * t)
    }

    fun lum(r: Float, g: Float, b: Float) = 0.2126f * r + 0.7152f * g + 0.0722f * b

    fun median(a: FloatArray, n: Int): Float {
        if (n <= 0) return 0f
        java.util.Arrays.sort(a, 0, n)
        return a[n / 2]
    }

    // ---------------------------------------------------------------- filters

    /** Mean filter with clamped borders, window (2r+1)^2, O(n). */
    fun box(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        if (r <= 0) return src.copyOf()
        val tmp = FloatArray(src.size)
        val dst = FloatArray(src.size)
        val norm = 1.0 / (2 * r + 1)
        for (y in 0 until h) {
            val row = y * w
            var s = 0.0
            for (k in -r..r) s += src[row + k.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[row + x] = (s * norm).toFloat()
                s += src[row + min(x + r + 1, w - 1)] - src[row + max(x - r, 0)]
            }
        }
        val col = DoubleArray(w)
        for (x in 0 until w) {
            var s = 0.0
            for (k in -r..r) s += tmp[k.coerceIn(0, h - 1) * w + x]
            col[x] = s
        }
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                dst[row + x] = (col[x] * norm).toFloat()
                col[x] += tmp[min(y + r + 1, h - 1) * w + x] - tmp[max(y - r, 0) * w + x]
            }
        }
        return dst
    }

    /** Separable max filter (dilation) with radius r. */
    fun dilate(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        if (r <= 0) return src.copyOf()
        val tmp = FloatArray(src.size)
        val dst = FloatArray(src.size)
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                var m = 0f
                for (k in max(0, x - r)..min(w - 1, x + r)) if (src[row + k] > m) m = src[row + k]
                tmp[row + x] = m
            }
        }
        for (y in 0 until h) {
            for (x in 0 until w) {
                var m = 0f
                for (k in max(0, y - r)..min(h - 1, y + r)) if (tmp[k * w + x] > m) m = tmp[k * w + x]
                dst[y * w + x] = m
            }
        }
        return dst
    }

    /**
     * Normalised convolution: smooth [value]*[weight] and [weight] with the same box and divide.
     * Returns (mean, coverage) where coverage = fraction of the window that carried weight.
     */
    fun normBox(value: FloatArray, weight: FloatArray, w: Int, h: Int, r: Int): Pair<FloatArray, FloatArray> {
        val vw = FloatArray(value.size) { value[it] * weight[it] }
        val num = box(vw, w, h, r)
        val den = box(weight, w, h, r)
        val mean = FloatArray(value.size) { if (den[it] > 1e-6f) num[it] / den[it] else 0f }
        return Pair(mean, den)
    }

    /**
     * Edge preserving smoothing (self-guided guided filter, He et al.).
     * Flat areas are smoothed, strong edges (variance >> eps) are kept, so no halos.
     */
    fun guidedSelf(src: FloatArray, w: Int, h: Int, r: Int, eps: Float): FloatArray {
        val mean = box(src, w, h, r)
        val sq = FloatArray(src.size) { src[it] * src[it] }
        val meanSq = box(sq, w, h, r)
        val a = FloatArray(src.size)
        val b = FloatArray(src.size)
        for (i in src.indices) {
            val v = max(meanSq[i] - mean[i] * mean[i], 0f)
            a[i] = v / (v + eps)
            b[i] = mean[i] * (1f - a[i])
        }
        val ma = box(a, w, h, r)
        val mb = box(b, w, h, r)
        return FloatArray(src.size) { ma[it] * src[it] + mb[it] }
    }

    /** 3x3 median of a field (used to throw away bad flow vectors). */
    fun median3(src: FloatArray, w: Int, h: Int): FloatArray {
        val dst = FloatArray(src.size)
        val t = FloatArray(9)
        for (y in 0 until h) for (x in 0 until w) {
            var n = 0
            for (dy in -1..1) for (dx in -1..1) {
                t[n++] = src[(y + dy).coerceIn(0, h - 1) * w + (x + dx).coerceIn(0, w - 1)]
            }
            java.util.Arrays.sort(t)
            dst[y * w + x] = t[4]
        }
        return dst
    }

    /** Bilinear sample of a float field at (x, y) with clamping. */
    fun sample(src: FloatArray, w: Int, h: Int, x: Float, y: Float): Float {
        val xc = if (x < 0f) 0f else if (x > w - 1f) w - 1f else x
        val yc = if (y < 0f) 0f else if (y > h - 1f) h - 1f else y
        val x0 = xc.toInt()
        val y0 = yc.toInt()
        val x1 = min(x0 + 1, w - 1)
        val y1 = min(y0 + 1, h - 1)
        val fx = xc - x0
        val fy = yc - y0
        val a = src[y0 * w + x0] * (1f - fx) + src[y0 * w + x1] * fx
        val b = src[y1 * w + x0] * (1f - fx) + src[y1 * w + x1] * fx
        return a * (1f - fy) + b * fy
    }

    fun absf(x: Float) = abs(x)
    fun expf(x: Float) = exp(x)
}
