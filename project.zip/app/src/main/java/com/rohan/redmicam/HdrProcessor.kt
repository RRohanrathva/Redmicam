package com.rohan.redmicam

import android.graphics.Bitmap
import kotlin.math.min
import kotlin.math.pow

/**
 * Simple single-shot "HDR-look" tone mapper:
 * lifts shadows, rolls off highlights and adds a little saturation.
 * Works in row chunks so large photos do not need a second huge int array.
 */
object HdrProcessor {

    private const val SATURATION = 1.12f
    private const val MAX_GAIN = 3.0f
    private const val CHUNK_ROWS = 128

    private val gainLut: FloatArray by lazy {
        FloatArray(256) { i ->
            if (i == 0) {
                MAX_GAIN
            } else {
                val l = i / 255f
                val lifted = l.pow(0.78f)
                // highlight roll-off above 0.75, then renormalise so 1.0 stays 1.0
                val rolled = if (lifted > 0.75f) 0.75f + (lifted - 0.75f) * 0.6f else lifted
                val target = rolled / 0.90f
                min(MAX_GAIN, target / l)
            }
        }
    }

    fun processSingleClickHdr(src: Bitmap): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val w = out.width
        val h = out.height
        val buf = IntArray(w * CHUNK_ROWS)

        var y = 0
        while (y < h) {
            val rows = min(CHUNK_ROWS, h - y)
            out.getPixels(buf, 0, w, 0, y, w, rows)

            for (i in 0 until w * rows) {
                val p = buf[i]
                val a = p ushr 24
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF

                val lum = 0.299f * r + 0.587f * g + 0.114f * b
                val gain = gainLut[lum.toInt().coerceIn(0, 255)]
                val newLum = lum * gain

                val nr = channel(r, gain, newLum)
                val ng = channel(g, gain, newLum)
                val nb = channel(b, gain, newLum)

                buf[i] = (a shl 24) or (nr shl 16) or (ng shl 8) or nb
            }

            out.setPixels(buf, 0, w, 0, y, w, rows)
            y += rows
        }
        return out
    }

    private fun channel(c: Int, gain: Float, newLum: Float): Int {
        val v = newLum + (c * gain - newLum) * SATURATION
        return v.toInt().coerceIn(0, 255)
    }
}
