package com.rohan.redmicam

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Multi-frame HDR (frames[0] = normal exposure, the rest progressively darker).
 *
 *  1. align every darker frame onto the normal frame (translation only)
 *  2. measure the real exposure ratio between neighbouring frames from the pixels
 *  3. merge all frames into one linear "radiance" image (noise-aware weights:
 *     bright frame everywhere it is not clipped, darker frames only where needed)
 *  4. edge-aware local tone mapping (guided filter base/detail split)
 *
 * Works row by row so memory stays low. Runs in the background service.
 */
object HdrProcessor {

    private const val BLOCK = 4
    private const val TARGET_STOPS = 4.5f
    private const val DETAIL_BOOST = 1.15f
    private const val SATURATION = 1.10f
    private const val ENC_SIZE = 4096
    private const val GF_RADIUS = 12
    private const val GF_EPS = 0.12f

    private val toLinear = FloatArray(256) { i ->
        val c = i / 255f
        if (c <= 0.04045f) c / 12.92f else ((c + 0.055f) / 1.055f).pow(2.4f)
    }

    private val toSrgb = IntArray(ENC_SIZE + 1) { i ->
        val l = i / ENC_SIZE.toFloat()
        val c = if (l <= 0.0031308f) l * 12.92f else 1.055f * l.pow(1f / 2.4f) - 0.055f
        (c * 255f + 0.5f).toInt().coerceIn(0, 255)
    }

    private fun smooth(t: Float): Float {
        val c = t.coerceIn(0f, 1f)
        return c * c * (3f - 2f * c)
    }

    /** Weight of a pixel by its brightest channel (gamma 0..1): ignore clipped and very dark pixels. */
    private fun weight(m: Float): Float {
        val lo = max(smooth((m - 0.02f) / 0.10f), 1e-3f)
        val hi = 1f - smooth((m - 0.80f) / 0.18f)
        return lo * hi
    }

    private fun enc(v: Float): Int = toSrgb[(v * ENC_SIZE).toInt().coerceIn(0, ENC_SIZE)]

    private fun linLum(p: Int): Float =
        0.2126f * toLinear[(p shr 16) and 0xFF] +
            0.7152f * toLinear[(p shr 8) and 0xFF] +
            0.0722f * toLinear[p and 0xFF]

    /** Row-wise access to all frames with their alignment offsets. */
    private class FrameSet(
        val bmps: List<Bitmap>,
        val dx: IntArray,
        val dy: IntArray,
        val scale: FloatArray
    ) {
        val n = bmps.size
        val w = bmps[0].width
        val h = bmps[0].height
        private val rows = Array(n) { IntArray(w) }
        private val rowOk = BooleanArray(n)

        fun loadRow(y: Int) {
            for (i in 0 until n) {
                val yy = y + dy[i]
                if (yy in 0 until h) {
                    bmps[i].getPixels(rows[i], 0, w, 0, yy, w, 1)
                    rowOk[i] = true
                } else {
                    rowOk[i] = false
                }
            }
        }

        /** Merged linear RGB (written to rgb) in reference-exposure units; returns luminance. */
        fun radiance(x: Int, rgb: FloatArray): Float {
            var sumW = 0f
            var sr = 0f
            var sg = 0f
            var sb = 0f
            var fr = 0f
            var fg = 0f
            var fb = 0f
            for (i in 0 until n) {
                if (!rowOk[i]) continue
                val sx = x + dx[i]
                if (sx < 0 || sx >= w) continue
                val p = rows[i][sx]
                val r8 = (p shr 16) and 0xFF
                val g8 = (p shr 8) and 0xFF
                val b8 = p and 0xFF
                val s = scale[i]
                val lr = HdrProcessor.toLinear[r8] * s
                val lg = HdrProcessor.toLinear[g8] * s
                val lb = HdrProcessor.toLinear[b8] * s
                // last valid frame = darkest, used when every frame is clipped
                fr = lr
                fg = lg
                fb = lb
                val m = max(r8, max(g8, b8)) / 255f
                val wgt = HdrProcessor.weight(m) / (s * s)
                if (wgt > 0f) {
                    sumW += wgt
                    sr += lr * wgt
                    sg += lg * wgt
                    sb += lb * wgt
                }
            }
            if (sumW > 1e-9f) {
                rgb[0] = sr / sumW
                rgb[1] = sg / sumW
                rgb[2] = sb / sumW
            } else {
                rgb[0] = fr
                rgb[1] = fg
                rgb[2] = fb
            }
            return 0.2126f * rgb[0] + 0.7152f * rgb[1] + 0.0722f * rgb[2]
        }
    }

    /**
     * @param input frames[0] = normal exposure, then darker ones. Caller keeps ownership.
     */
    fun merge(input: List<Bitmap>): Bitmap {
        val ref = input[0]
        val w = ref.width
        val h = ref.height

        val frames = ArrayList<Bitmap>()
        frames.add(ref)
        for (i in 1 until input.size) {
            if (input[i].width == w && input[i].height == h) frames.add(input[i])
        }
        val n = frames.size

        val dx = IntArray(n)
        val dy = IntArray(n)
        val scale = FloatArray(n) { 1f }
        for (i in 1 until n) {
            val s = estimateShift(ref, frames[i])
            dx[i] = s.first
            dy[i] = s.second
        }
        for (i in 1 until n) {
            val k = estimateRatio(frames[i - 1], dx[i - 1], dy[i - 1], frames[i], dx[i], dy[i])
            scale[i] = scale[i - 1] * k
        }

        val fs = FrameSet(frames, dx, dy, scale)
        val rgb = FloatArray(3)

        // ---------- pass 1: low-res log luminance of the merged radiance ----------
        val lw = (w + BLOCK - 1) / BLOCK
        val lh = (h + BLOCK - 1) / BLOCK
        val lowSum = FloatArray(lw * lh)
        val lowCnt = FloatArray(lw * lh)

        var y = 0
        while (y < h) {
            fs.loadRow(y)
            val cellRow = (y / BLOCK) * lw
            var x = 0
            while (x < w) {
                val lum = fs.radiance(x, rgb)
                val cell = cellRow + x / BLOCK
                lowSum[cell] += ln(max(lum, 1e-5f))
                lowCnt[cell] += 1f
                x += 2
            }
            y += 2
        }

        val lowRaw = FloatArray(lw * lh) { lowSum[it] / max(lowCnt[it], 1f) }
        val pass1 = guidedFilter(lowRaw, lowRaw, lw, lh, GF_RADIUS, GF_EPS)
        val base = guidedFilter(pass1, lowRaw, lw, lh, GF_RADIUS, GF_EPS)

        val sorted = base.copyOf()
        sorted.sort()
        val cnt = sorted.size
        val bMin = sorted[(cnt * 0.02f).toInt().coerceIn(0, cnt - 1)]
        val bMax = sorted[(cnt * 0.98f).toInt().coerceIn(0, cnt - 1)]
        val bMed = sorted[cnt / 2]

        val stops = (bMax - bMin) / ln(2f)
        val comp = if (stops <= TARGET_STOPS) 1f else (TARGET_STOPS / stops).coerceIn(0.35f, 1f)
        val logTarget = ln(exp(bMed).coerceIn(0.15f, 0.28f))

        val xi0 = IntArray(w)
        val xi1 = IntArray(w)
        val xf = FloatArray(w)
        for (x in 0 until w) {
            val fx = ((x + 0.5f) / BLOCK - 0.5f).coerceIn(0f, (lw - 1).toFloat())
            val i0 = fx.toInt()
            xi0[x] = i0
            xi1[x] = min(i0 + 1, lw - 1)
            xf[x] = fx - i0
        }

        // ---------- pass 2: merge + tone map ----------
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val rowOut = IntArray(w)
        y = 0
        while (y < h) {
            fs.loadRow(y)
            val fy = ((y + 0.5f) / BLOCK - 0.5f).coerceIn(0f, (lh - 1).toFloat())
            val y0 = fy.toInt()
            val y1 = min(y0 + 1, lh - 1)
            val yf = fy - y0
            val row0 = y0 * lw
            val row1 = y1 * lw

            for (x in 0 until w) {
                val lum = fs.radiance(x, rgb)
                val l = max(lum, 1e-5f)
                val logL = ln(l)

                val a = xf[x]
                val b0 = base[row0 + xi0[x]] * (1f - a) + base[row0 + xi1[x]] * a
                val b1 = base[row1 + xi0[x]] * (1f - a) + base[row1 + xi1[x]] * a
                val bs = b0 + (b1 - b0) * yf

                val lo = logTarget + comp * (bs - bMed) + DETAIL_BOOST * (logL - bs)
                var lOut = exp(lo)
                if (lOut > 0.7f) {
                    lOut = 0.7f + 0.3f * (1f - exp(-(lOut - 0.7f) / 0.3f))
                }

                val sc = lOut / l
                var cr = lOut + (rgb[0] * sc - lOut) * SATURATION
                var cg = lOut + (rgb[1] * sc - lOut) * SATURATION
                var cb = lOut + (rgb[2] * sc - lOut) * SATURATION
                if (cr < 0f) cr = 0f
                if (cg < 0f) cg = 0f
                if (cb < 0f) cb = 0f
                val m = max(cr, max(cg, cb))
                if (m > 1f) {
                    val inv = 1f / m
                    cr *= inv
                    cg *= inv
                    cb *= inv
                }
                rowOut[x] = (0xFF shl 24) or (enc(cr) shl 16) or (enc(cg) shl 8) or enc(cb)
            }
            out.setPixels(rowOut, 0, w, 0, y, w, 1)
            y++
        }
        return out
    }

    // ------------------------------------------------------------------ exposure ratio

    /** Median linear ratio ref/cur (after alignment) on well-exposed pixels = real exposure step. */
    private fun estimateRatio(
        a: Bitmap, adx: Int, ady: Int,
        b: Bitmap, bdx: Int, bdy: Int
    ): Float {
        val w = a.width
        val h = a.height
        val step = 7
        val samples = FloatArray((w / step + 2) * (h / step + 2))
        var cnt = 0
        val rowA = IntArray(w)
        val rowB = IntArray(w)
        var y = 0
        while (y < h) {
            val ya = y + ady
            val yb = y + bdy
            if (ya in 0 until h && yb in 0 until h) {
                a.getPixels(rowA, 0, w, 0, ya, w, 1)
                b.getPixels(rowB, 0, w, 0, yb, w, 1)
                var x = 0
                while (x < w) {
                    val xa = x + adx
                    val xb = x + bdx
                    if (xa in 0 until w && xb in 0 until w) {
                        val la = linLum(rowA[xa])
                        val lb = linLum(rowB[xb])
                        if (la in 0.05f..0.40f && lb > 0.008f && cnt < samples.size) {
                            samples[cnt++] = la / lb
                        }
                    }
                    x += step
                }
            }
            y += step
        }
        if (cnt < 300) return 4f
        java.util.Arrays.sort(samples, 0, cnt)
        return samples[cnt / 2].coerceIn(1.4f, 12f)
    }

    // ------------------------------------------------------------------ alignment

    /** Returns (dx, dy) such that ref(x, y) ~ cur(x + dx, y + dy), in full-res pixels. */
    private fun estimateShift(ref: Bitmap, cur: Bitmap): Pair<Int, Int> {
        val s1 = shiftAtScale(ref, cur, 8, 0, 0, 12, 2)
        val s2 = shiftAtScale(ref, cur, 2, s1.first * 4, s1.second * 4, 5, 4)
        return Pair(s2.first * 2, s2.second * 2)
    }

    private fun shiftAtScale(
        n: Bitmap, u: Bitmap, div: Int, cx: Int, cy: Int, range: Int, step: Int
    ): Pair<Int, Int> {
        val sw = n.width / div
        val sh = n.height / div
        val m = max(abs(cx), abs(cy)) + range
        if (sw < 32 || sh < 32 || sw <= 2 * m + 8 || sh <= 2 * m + 8) return Pair(cx, cy)

        val a = scaledLuma(n, sw, sh)
        val b = scaledLuma(u, sw, sh)

        val centerSad = sad(a, b, sw, sh, cx, cy, m, step)
        var best = centerSad
        var bx = cx
        var by = cy
        for (sy in (cy - range)..(cy + range)) {
            for (sx in (cx - range)..(cx + range)) {
                val s = sad(a, b, sw, sh, sx, sy, m, step)
                if (s < best) {
                    best = s
                    bx = sx
                    by = sy
                }
            }
        }
        return if (best < centerSad * 0.92f) Pair(bx, by) else Pair(cx, cy)
    }

    private fun sad(
        a: FloatArray, b: FloatArray, w: Int, h: Int, sx: Int, sy: Int, m: Int, step: Int
    ): Float {
        var s = 0f
        var c = 0
        var y = m
        while (y < h - m) {
            var x = m
            while (x < w - m) {
                s += abs(a[y * w + x] - b[(y + sy) * w + x + sx])
                c++
                x += step
            }
            y += step
        }
        return s / max(c, 1)
    }

    /** Downscaled luminance normalised to zero mean / unit deviation (exposure independent). */
    private fun scaledLuma(src: Bitmap, sw: Int, sh: Int): FloatArray {
        val sb = Bitmap.createScaledBitmap(src, sw, sh, true)
        val px = IntArray(sw * sh)
        sb.getPixels(px, 0, sw, 0, 0, sw, sh)
        if (sb !== src) sb.recycle()

        val out = FloatArray(px.size)
        var sum = 0.0
        for (i in px.indices) {
            val p = px[i]
            val l = 0.299f * ((p shr 16) and 0xFF) + 0.587f * ((p shr 8) and 0xFF) + 0.114f * (p and 0xFF)
            out[i] = l
            sum += l
        }
        val mean = (sum / px.size).toFloat()
        var v = 0.0
        for (x in out) v += ((x - mean) * (x - mean)).toDouble()
        val std = sqrt(v / out.size).toFloat().coerceAtLeast(1f)
        for (i in out.indices) out[i] = (out[i] - mean) / std
        return out
    }

    // ------------------------------------------------------------------ guided filter (edge-aware smoothing)

    private fun boxMean(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val tmp = FloatArray(src.size)
        val out = FloatArray(src.size)
        val pre = DoubleArray(max(w, h) + 1)
        for (y in 0 until h) {
            val row = y * w
            pre[0] = 0.0
            for (x in 0 until w) pre[x + 1] = pre[x] + src[row + x]
            for (x in 0 until w) {
                val lo = max(0, x - r)
                val hi = min(w - 1, x + r)
                tmp[row + x] = ((pre[hi + 1] - pre[lo]) / (hi - lo + 1)).toFloat()
            }
        }
        for (x in 0 until w) {
            pre[0] = 0.0
            for (y in 0 until h) pre[y + 1] = pre[y] + tmp[y * w + x]
            for (y in 0 until h) {
                val lo = max(0, y - r)
                val hi = min(h - 1, y + r)
                out[y * w + x] = ((pre[hi + 1] - pre[lo]) / (hi - lo + 1)).toFloat()
            }
        }
        return out
    }

    private fun guidedFilter(
        p: FloatArray, guide: FloatArray, w: Int, h: Int, r: Int, eps: Float
    ): FloatArray {
        val n = p.size
        val meanI = boxMean(guide, w, h, r)
        val meanP = boxMean(p, w, h, r)
        val corrIP = boxMean(FloatArray(n) { guide[it] * p[it] }, w, h, r)
        val corrII = boxMean(FloatArray(n) { guide[it] * guide[it] }, w, h, r)
        val a = FloatArray(n)
        val b = FloatArray(n)
        for (i in 0 until n) {
            val varI = corrII[i] - meanI[i] * meanI[i]
            val covIP = corrIP[i] - meanI[i] * meanP[i]
            a[i] = covIP / (varI + eps)
            b[i] = meanP[i] - a[i] * meanI[i]
        }
        val meanA = boxMean(a, w, h, r)
        val meanB = boxMean(b, w, h, r)
        return FloatArray(n) { meanA[it] * guide[it] + meanB[it] }
    }
}
