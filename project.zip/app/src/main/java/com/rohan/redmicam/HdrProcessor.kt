package com.rohan.redmicam

import android.graphics.Bitmap
import android.graphics.Canvas
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Two-frame HDR:
 *  1. align the dark frame onto the normal frame (translation only)
 *  2. measure the real exposure ratio between the frames from the pixels themselves
 *  3. merge both into one linear "radiance" image (highlights come from the dark frame,
 *     everything else from the normal frame)
 *  4. local tone mapping (base/detail split) so shadows are lifted, highlights are
 *     recovered and local contrast is kept.
 * Works in row chunks so memory stays low even for ~8MP photos.
 */
object HdrProcessor {

    private const val CHUNK_ROWS = 64
    private const val BLOCK = 8
    private const val TARGET_STOPS = 4.5f
    private const val DETAIL_BOOST = 1.15f
    private const val SATURATION = 1.10f
    private const val ENC_SIZE = 4096

    private val toLinear = FloatArray(256) { i ->
        val c = i / 255f
        if (c <= 0.04045f) c / 12.92f else ((c + 0.055f) / 1.055f).pow(2.4f)
    }

    private val toSrgb = IntArray(ENC_SIZE + 1) { i ->
        val l = i / ENC_SIZE.toFloat()
        val c = if (l <= 0.0031308f) l * 12.92f else 1.055f * l.pow(1f / 2.4f) - 0.055f
        (c * 255f + 0.5f).toInt().coerceIn(0, 255)
    }

    /**
     * @param normal normal-exposure frame
     * @param underIn darker frame (can be null -> single-frame tone mapping only)
     * The caller keeps ownership of both bitmaps.
     */
    fun merge(normal: Bitmap, underIn: Bitmap?): Bitmap {
        val w = normal.width
        val h = normal.height

        var aligned: Bitmap? = null
        var k = 4f
        if (underIn != null && underIn.width == w && underIn.height == h) {
            val shift = estimateShift(normal, underIn)
            aligned = if (shift.first != 0 || shift.second != 0) {
                shiftBitmap(underIn, shift.first, shift.second)
            } else {
                underIn
            }
            k = estimateRatio(normal, aligned)
        }
        val u: Bitmap? = aligned
        val useUnder = u != null

        try {
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val rgb = FloatArray(3)
            val bufN = IntArray(w * CHUNK_ROWS)
            val bufU = IntArray(w * CHUNK_ROWS)
            val bufOut = IntArray(w * CHUNK_ROWS)

            // ---------- pass 1: low-res log luminance of the merged radiance ----------
            val lw = (w + BLOCK - 1) / BLOCK
            val lh = (h + BLOCK - 1) / BLOCK
            val lowSum = FloatArray(lw * lh)
            val lowCnt = FloatArray(lw * lh)

            var y = 0
            while (y < h) {
                val rows = min(CHUNK_ROWS, h - y)
                normal.getPixels(bufN, 0, w, 0, y, w, rows)
                if (u != null) u.getPixels(bufU, 0, w, 0, y, w, rows)
                for (r in 0 until rows) {
                    if ((y + r) % 2 != 0) continue
                    val cellRow = ((y + r) / BLOCK) * lw
                    var x = 0
                    while (x < w) {
                        val i = r * w + x
                        val lum = radiance(bufN[i], if (useUnder) bufU[i] else 0, useUnder, k, rgb)
                        val cell = cellRow + x / BLOCK
                        lowSum[cell] += ln(max(lum, 1e-5f))
                        lowCnt[cell] += 1f
                        x += 2
                    }
                }
                y += rows
            }

            var low = FloatArray(lw * lh) { lowSum[it] / max(lowCnt[it], 1f) }
            low = boxBlur(boxBlur(low, lw, lh, 6), lw, lh, 6)

            val sorted = low.copyOf()
            sorted.sort()
            val n = sorted.size
            val bMin = sorted[(n * 0.02f).toInt().coerceIn(0, n - 1)]
            val bMax = sorted[(n * 0.98f).toInt().coerceIn(0, n - 1)]
            val bMed = sorted[n / 2]

            val stops = (bMax - bMin) / ln(2f)
            val comp = if (stops <= TARGET_STOPS) 1f else (TARGET_STOPS / stops).coerceIn(0.35f, 1f)
            val logTarget = ln(exp(bMed).coerceIn(0.15f, 0.28f))

            // column interpolation tables
            val xi0 = IntArray(w)
            val xi1 = IntArray(w)
            val xf = FloatArray(w)
            for (x in 0 until w) {
                val fx = ((x + 0.5f) / BLOCK - 0.5f).coerceIn(0f, (lw - 1).toFloat())
                val i0 = fx.toInt()
                xi0[x] = i0
                xi1[x] = min(i0 + 1, lw - 1)
                xf[x] = fx - i0
            }

            // ---------- pass 2: merge + tone map ----------
            y = 0
            while (y < h) {
                val rows = min(CHUNK_ROWS, h - y)
                normal.getPixels(bufN, 0, w, 0, y, w, rows)
                if (u != null) u.getPixels(bufU, 0, w, 0, y, w, rows)
                for (r in 0 until rows) {
                    val fy = (((y + r) + 0.5f) / BLOCK - 0.5f).coerceIn(0f, (lh - 1).toFloat())
                    val y0 = fy.toInt()
                    val y1 = min(y0 + 1, lh - 1)
                    val yf = fy - y0
                    val row0 = y0 * lw
                    val row1 = y1 * lw

                    for (x in 0 until w) {
                        val i = r * w + x
                        val lum = radiance(bufN[i], if (useUnder) bufU[i] else 0, useUnder, k, rgb)
                        val l = max(lum, 1e-5f)
                        val logL = ln(l)

                        val a = xf[x]
                        val b0 = low[row0 + xi0[x]] * (1f - a) + low[row0 + xi1[x]] * a
                        val b1 = low[row1 + xi0[x]] * (1f - a) + low[row1 + xi1[x]] * a
                        val base = b0 + (b1 - b0) * yf

                        val lo = logTarget + comp * (base - bMed) + DETAIL_BOOST * (logL - base)
                        var lOut = exp(lo)
                        if (lOut > 0.7f) {
                            lOut = 0.7f + 0.3f * (1f - exp(-(lOut - 0.7f) / 0.3f))
                        }

                        val sc = lOut / l
                        var cr = lOut + (rgb[0] * sc - lOut) * SATURATION
                        var cg = lOut + (rgb[1] * sc - lOut) * SATURATION
                        var cb = lOut + (rgb[2] * sc - lOut) * SATURATION
                        if (cr < 0f) cr = 0f
                        if (cg < 0f) cg = 0f
                        if (cb < 0f) cb = 0f
                        val m = max(cr, max(cg, cb))
                        if (m > 1f) {
                            val inv = 1f / m
                            cr *= inv
                            cg *= inv
                            cb *= inv
                        }

                        bufOut[i] = (0xFF shl 24) or
                            (enc(cr) shl 16) or
                            (enc(cg) shl 8) or
                            enc(cb)
                    }
                }
                out.setPixels(bufOut, 0, w, 0, y, w, rows)
                y += rows
            }
            return out
        } finally {
            if (u != null && u !== underIn) u.recycle()
        }
    }

    private fun enc(v: Float): Int =
        toSrgb[(v * ENC_SIZE).toInt().coerceIn(0, ENC_SIZE)]

    /** Linear RGB of the merged pixel written to [rgb]; returns its luminance. */
    private fun radiance(pn: Int, pu: Int, hasU: Boolean, k: Float, rgb: FloatArray): Float {
        val nr = (pn shr 16) and 0xFF
        val ng = (pn shr 8) and 0xFF
        val nb = pn and 0xFF
        var r = toLinear[nr]
        var g = toLinear[ng]
        var b = toLinear[nb]

        if (hasU && (pu ushr 24) != 0) {
            val maxC = max(nr, max(ng, nb)) / 255f
            val t = ((maxC - 0.72f) / (0.97f - 0.72f)).coerceIn(0f, 1f)
            val wU = t * t * (3f - 2f * t)
            if (wU > 0f) {
                val ur = toLinear[(pu shr 16) and 0xFF] * k
                val ug = toLinear[(pu shr 8) and 0xFF] * k
                val ub = toLinear[pu and 0xFF] * k
                r += (ur - r) * wU
                g += (ug - g) * wU
                b += (ub - b) * wU
            }
        }
        rgb[0] = r
        rgb[1] = g
        rgb[2] = b
        return 0.2126f * r + 0.7152f * g + 0.0722f * b
    }

    private fun linLum(p: Int): Float =
        0.2126f * toLinear[(p shr 16) and 0xFF] +
            0.7152f * toLinear[(p shr 8) and 0xFF] +
            0.0722f * toLinear[p and 0xFF]

    /** Median linear ratio normal/under on well-exposed pixels = real exposure difference. */
    private fun estimateRatio(n: Bitmap, u: Bitmap): Float {
        val w = n.width
        val h = n.height
        val step = 7
        val samples = FloatArray((w / step + 2) * (h / step + 2))
        var cnt = 0
        val rowN = IntArray(w)
        val rowU = IntArray(w)
        var y = 0
        while (y < h) {
            n.getPixels(rowN, 0, w, 0, y, w, 1)
            u.getPixels(rowU, 0, w, 0, y, w, 1)
            var x = 0
            while (x < w) {
                val pu = rowU[x]
                if ((pu ushr 24) != 0) {
                    val ln0 = linLum(rowN[x])
                    val lu = linLum(pu)
                    if (ln0 in 0.05f..0.40f && lu > 0.008f && cnt < samples.size) {
                        samples[cnt++] = ln0 / lu
                    }
                }
                x += step
            }
            y += step
        }
        if (cnt < 300) return 4f
        java.util.Arrays.sort(samples, 0, cnt)
        return samples[cnt / 2].coerceIn(1.5f, 10f)
    }

    // ------------------------------------------------------------------ alignment

    /** Returns (dx, dy) such that normal(x, y) ~ under(x + dx, y + dy), in full-res pixels. */
    private fun estimateShift(n: Bitmap, u: Bitmap): Pair<Int, Int> {
        val s1 = shiftAtScale(n, u, 8, 0, 0, 12, 2)
        val s2 = shiftAtScale(n, u, 2, s1.first * 4, s1.second * 4, 5, 4)
        return Pair(s2.first * 2, s2.second * 2)
    }

    private fun shiftAtScale(
        n: Bitmap, u: Bitmap, div: Int, cx: Int, cy: Int, range: Int, step: Int
    ): Pair<Int, Int> {
        val sw = n.width / div
        val sh = n.height / div
        val m = max(abs(cx), abs(cy)) + range
        if (sw < 32 || sh < 32 || sw <= 2 * m + 8 || sh <= 2 * m + 8) return Pair(cx, cy)

        val a = scaledLuma(n, sw, sh)
        val b = scaledLuma(u, sw, sh)

        val centerSad = sad(a, b, sw, sh, cx, cy, m, step)
        var best = centerSad
        var bx = cx
        var by = cy
        for (sy in (cy - range)..(cy + range)) {
            for (sx in (cx - range)..(cx + range)) {
                val s = sad(a, b, sw, sh, sx, sy, m, step)
                if (s < best) {
                    best = s
                    bx = sx
                    by = sy
                }
            }
        }
        // only trust the shift if it is clearly better than the starting guess
        return if (best < centerSad * 0.92f) Pair(bx, by) else Pair(cx, cy)
    }

    private fun sad(
        a: FloatArray, b: FloatArray, w: Int, h: Int, sx: Int, sy: Int, m: Int, step: Int
    ): Float {
        var s = 0f
        var c = 0
        var y = m
        while (y < h - m) {
            var x = m
            while (x < w - m) {
                s += abs(a[y * w + x] - b[(y + sy) * w + x + sx])
                c++
                x += step
            }
            y += step
        }
        return s / max(c, 1)
    }

    /** Downscaled luminance, normalised to zero mean / unit deviation (exposure independent). */
    private fun scaledLuma(src: Bitmap, sw: Int, sh: Int): FloatArray {
        val sb = Bitmap.createScaledBitmap(src, sw, sh, true)
        val px = IntArray(sw * sh)
        sb.getPixels(px, 0, sw, 0, 0, sw, sh)
        if (sb !== src) sb.recycle()

        val out = FloatArray(px.size)
        var sum = 0.0
        for (i in px.indices) {
            val p = px[i]
            val l = 0.299f * ((p shr 16) and 0xFF) + 0.587f * ((p shr 8) and 0xFF) + 0.114f * (p and 0xFF)
            out[i] = l
            sum += l
        }
        val mean = (sum / px.size).toFloat()
        var v = 0.0
        for (x in out) v += ((x - mean) * (x - mean)).toDouble()
        val std = sqrt(v / out.size).toFloat().coerceAtLeast(1f)
        for (i in out.indices) out[i] = (out[i] - mean) / std
        return out
    }

    private fun shiftBitmap(src: Bitmap, sx: Int, sy: Int): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(src, (-sx).toFloat(), (-sy).toFloat(), null)
        return out
    }

    // ------------------------------------------------------------------ helpers

    private fun boxBlur(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val tmp = FloatArray(src.size)
        val dst = FloatArray(src.size)
        val norm = 1f / (2 * r + 1)
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                var s = 0f
                for (dx in -r..r) s += src[row + (x + dx).coerceIn(0, w - 1)]
                tmp[row + x] = s * norm
            }
        }
        for (y in 0 until h) {
            for (x in 0 until w) {
                var s = 0f
                for (dy in -r..r) s += tmp[(y + dy).coerceIn(0, h - 1) * w + x]
                dst[y * w + x] = s * norm
            }
        }
        return dst
    }
}
