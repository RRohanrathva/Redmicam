package com.rohan.redmicam

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import com.rohan.redmicam.hdr.RowSink
import com.rohan.redmicam.hdr.RowSource
import kotlin.math.abs
import kotlin.math.roundToInt

/** Bitmap <-> HDR engine glue. */
class BitmapRowSource(private val bmp: Bitmap) : RowSource {
    override val width: Int get() = bmp.width
    override val height: Int get() = bmp.height
    override fun readRows(y: Int, rows: Int, out: IntArray) {
        bmp.getPixels(out, 0, bmp.width, 0, y, bmp.width, rows)
    }
}

class BitmapRowSink(private val bmp: Bitmap) : RowSink {
    override fun writeRows(y: Int, rows: Int, px: IntArray) {
        bmp.setPixels(px, 0, bmp.width, 0, y, bmp.width, rows)
    }
}

object FrameIo {

    /**
     * Decodes a camera JPEG, turns it upright and (optionally) centre-crops it to [cropAspect]
     * (width / height; 0 = no crop). [decode] receives the prepared options.
     */
    fun load(
        sample: Int,
        rotation: Int,
        cropAspect: Float,
        decode: (BitmapFactory.Options) -> Bitmap?
    ): Bitmap? {
        val opts = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inSampleSize = if (sample < 1) 1 else sample
        }
        var bmp = decode(opts) ?: return null

        if (rotation != 0) {
            val m = Matrix().apply { postRotate(rotation.toFloat()) }
            val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (r !== bmp) bmp.recycle()
            bmp = r
        }

        if (cropAspect > 0f) {
            val w = bmp.width
            val h = bmp.height
            val cur = w.toFloat() / h
            if (abs(cur - cropAspect) > 0.01f) {
                val c: Bitmap = if (cur > cropAspect) {
                    val nw = (h * cropAspect).roundToInt().coerceIn(1, w)
                    Bitmap.createBitmap(bmp, (w - nw) / 2, 0, nw, h)
                } else {
                    val nh = (w / cropAspect).roundToInt().coerceIn(1, h)
                    Bitmap.createBitmap(bmp, 0, (h - nh) / 2, w, nh)
                }
                if (c !== bmp) bmp.recycle()
                bmp = c
            }
        }
        return bmp
    }
}
